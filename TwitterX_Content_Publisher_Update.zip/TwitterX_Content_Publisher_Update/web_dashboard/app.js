const state = {
  data: null,
  selectedId: null,
  queue: "today",
  filters: {
    search: "",
    status: "all",
    category: "all",
    riskOnly: false,
  },
};

const stateClass = {
  draft: "warning",
  review: "warning",
  ready: "good",
  scheduled: "good",
  published: "",
  rejected: "danger",
  unknown: "",
};

const els = {
  refreshBtn: document.querySelector("#refreshBtn"),
  feishuLink: document.querySelector("#feishuLink"),
  sourceLabel: document.querySelector("#sourceLabel"),
  configLabel: document.querySelector("#configLabel"),
  updatedAt: document.querySelector("#updatedAt"),
  warningBox: document.querySelector("#warningBox"),
  metricGrid: document.querySelector("#metricGrid"),
  categoryList: document.querySelector("#categoryList"),
  riskList: document.querySelector("#riskList"),
  timeline: document.querySelector("#timeline"),
  queueTabs: document.querySelector("#queueTabs"),
  queueList: document.querySelector("#queueList"),
  searchInput: document.querySelector("#searchInput"),
  statusFilter: document.querySelector("#statusFilter"),
  categoryFilter: document.querySelector("#categoryFilter"),
  riskOnly: document.querySelector("#riskOnly"),
  postRows: document.querySelector("#postRows"),
  detailMeta: document.querySelector("#detailMeta"),
  detailBody: document.querySelector("#detailBody"),
  detailTags: document.querySelector("#detailTags"),
  copyBtn: document.querySelector("#copyBtn"),
};

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function pct(value, max) {
  if (!max) return 0;
  return Math.max(4, Math.min(100, Math.round((value / max) * 100)));
}

function isRiskPost(post) {
  return post.is_due || post.metrics.weighted_length > 280 || ((post.state === "ready" || post.state === "scheduled") && !post.scheduled_at);
}

function metricCard(label, value, hint, tone = "") {
  return `
    <article class="metric-card ${tone}">
      <div class="label">${escapeHtml(label)}</div>
      <div class="value">${escapeHtml(value)}</div>
      <div class="hint">${escapeHtml(hint)}</div>
    </article>
  `;
}

async function loadDashboard(force = false) {
  els.refreshBtn.disabled = true;
  els.refreshBtn.textContent = force ? "刷新中" : "加载中";
  try {
    const response = await fetch(`/api/dashboard${force ? "?force=1" : ""}`, { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    if (data.ok === false) throw new Error(data.error || "数据加载失败");
    state.data = data;
    if (!state.selectedId && data.posts.length) {
      state.selectedId = data.posts[0].id;
    }
    render();
  } catch (error) {
    els.warningBox.hidden = false;
    els.warningBox.textContent = `看板加载失败：${error.message}`;
  } finally {
    els.refreshBtn.disabled = false;
    els.refreshBtn.textContent = "刷新数据";
  }
}

function render() {
  const data = state.data;
  if (!data) return;

  els.sourceLabel.textContent = data.source_label || "-";
  els.configLabel.textContent = data.config_summary || "-";
  els.updatedAt.textContent = data.generated_at || "-";

  if (data.base_url) {
    els.feishuLink.href = data.base_url;
    els.feishuLink.style.display = "";
  } else {
    els.feishuLink.style.display = "none";
  }

  if (data.warning) {
    els.warningBox.hidden = false;
    els.warningBox.textContent = data.warning;
  } else {
    els.warningBox.hidden = true;
    els.warningBox.textContent = "";
  }

  renderMetrics(data);
  renderCategories(data);
  renderRisks(data);
  renderTimeline(data);
  renderQueue(data);
  renderFilters(data);
  renderTable(data);
  renderDetail(data.posts.find((post) => post.id === state.selectedId) || data.posts[0]);
}

function renderMetrics(data) {
  const s = data.summary;
  els.metricGrid.innerHTML = [
    metricCard("内容池总量", s.active_total, `全部 ${s.total} 条，已发布 ${s.published} 条`, "good"),
    metricCard("可发布库存", s.publishable, `约 ${s.publishable_days} 天库存`, s.publishable < data.targets.daily * 3 ? "danger" : "good"),
    metricCard("待审核", s.review, "需要审核转入发布池", s.review ? "warning" : ""),
    metricCard("今日队列", s.today_queue, `到点 ${s.due} 条`, s.due ? "danger" : ""),
    metricCard("7 天排期", s.week_queue, `缺口 ${s.week_gap} 条`, s.week_gap ? "warning" : "good"),
    metricCard("长度风险", s.long, "超过普通 X 帖限制", s.long ? "warning" : ""),
  ].join("");
}

function renderCategories(data) {
  const maxActive = Math.max(1, ...data.category_stats.map((row) => row.active));
  els.categoryList.innerHTML = data.category_stats
    .map((row) => {
      const tone = row.health === "low" ? "low" : row.health === "review" ? "review" : "";
      const healthPill =
        row.health === "low"
          ? '<span class="pill danger">可发不足</span>'
          : row.health === "review"
            ? '<span class="pill warning">待审核多</span>'
            : '<span class="pill good">稳定</span>';
      return `
        <div class="category-row">
          <div>
            <div class="category-name">${escapeHtml(row.category)}</div>
            <span class="muted">活跃 ${row.active} / 总 ${row.total}</span>
          </div>
          <div class="bar-track" title="活跃内容占比">
            <div class="bar-fill ${tone}" style="width:${pct(row.active, maxActive)}%"></div>
          </div>
          <div class="category-counts">
            <span class="pill good">可发 ${row.publishable}</span>
            <span class="pill warning">待审 ${row.review}</span>
            <span class="pill">已排 ${row.scheduled}</span>
            ${healthPill}
          </div>
        </div>
      `;
    })
    .join("");
}

function renderRisks(data) {
  els.riskList.innerHTML = data.risks
    .map(
      (risk) => `
        <div class="risk-row ${escapeHtml(risk.level)}">
          <div class="risk-title">
            <span>${escapeHtml(risk.title)}</span>
            <span>${risk.count ? escapeHtml(risk.count) : ""}</span>
          </div>
          <div class="risk-detail">${escapeHtml(risk.detail)}</div>
        </div>
      `,
    )
    .join("");
}

function renderTimeline(data) {
  const daily = data.targets.daily;
  els.timeline.innerHTML = data.timeline
    .map(
      (day) => `
        <div class="day-row">
          <div>
            <div class="day-date">${escapeHtml(day.label)}</div>
            <span class="muted">${escapeHtml(day.date)}</span>
          </div>
          <div class="bar-track">
            <div class="bar-fill ${day.count < daily ? "review" : ""}" style="width:${pct(day.count, daily)}%"></div>
          </div>
          <div class="day-gap">${day.count}/${daily}<br />缺 ${day.gap}</div>
        </div>
      `,
    )
    .join("");
}

function renderQueue(data) {
  const rows = data.queues[state.queue] || [];
  if (!rows.length) {
    els.queueList.innerHTML = '<div class="empty">当前队列为空。</div>';
    return;
  }
  els.queueList.innerHTML = rows.map(queueRow).join("");
  els.queueList.querySelectorAll("[data-id]").forEach((node) => {
    node.addEventListener("click", () => {
      state.selectedId = node.dataset.id;
      renderTable(data);
      renderDetail(data.posts.find((post) => post.id === state.selectedId));
    });
  });
}

function queueRow(post) {
  const tone = stateClass[post.state] || "";
  return `
    <div class="queue-row" data-id="${escapeHtml(post.id)}">
      <div class="queue-time">${escapeHtml(post.scheduled_at || "未排期")}</div>
      <div><span class="pill ${tone}">${escapeHtml(post.state_label)}</span></div>
      <div class="queue-summary">
        <strong>${escapeHtml(post.id)} · ${escapeHtml(post.category)}</strong>
        <span>${escapeHtml(post.summary)}</span>
        <div class="queue-meta">${escapeHtml(post.assignee)} / ${escapeHtml(post.source)} / ${escapeHtml(post.platform)}</div>
      </div>
      <div class="queue-meta">X ${post.metrics.weighted_length}</div>
    </div>
  `;
}

function renderFilters(data) {
  const currentStatus = state.filters.status;
  const currentCategory = state.filters.category;
  const statuses = [{ value: "all", label: "全部状态" }, ...data.status_counts.map((item) => ({ value: item.state, label: item.label }))];
  const categories = [{ value: "all", label: "全部分类" }, ...data.category_stats.map((item) => ({ value: item.category, label: item.category }))];

  els.statusFilter.innerHTML = statuses
    .map((item) => `<option value="${escapeHtml(item.value)}">${escapeHtml(item.label)}</option>`)
    .join("");
  els.categoryFilter.innerHTML = categories
    .map((item) => `<option value="${escapeHtml(item.value)}">${escapeHtml(item.label)}</option>`)
    .join("");
  els.statusFilter.value = currentStatus;
  els.categoryFilter.value = currentCategory;
}

function filteredPosts(data) {
  const keyword = state.filters.search.trim().toLowerCase();
  return data.posts.filter((post) => {
    if (state.filters.status !== "all" && post.state !== state.filters.status) return false;
    if (state.filters.category !== "all" && post.category !== state.filters.category) return false;
    if (state.filters.riskOnly && !isRiskPost(post)) return false;
    if (!keyword) return true;
    const blob = [post.id, post.status, post.category, post.tags_text, post.assignee, post.summary, post.text].join(" ").toLowerCase();
    return blob.includes(keyword);
  });
}

function renderTable(data) {
  const rows = filteredPosts(data);
  if (!rows.length) {
    els.postRows.innerHTML = '<tr><td colspan="6" class="empty">没有符合筛选条件的内容。</td></tr>';
    return;
  }
  els.postRows.innerHTML = rows
    .slice(0, 240)
    .map((post) => {
      const tone = stateClass[post.state] || "";
      const selected = post.id === state.selectedId ? "selected" : "";
      const lengthTone = post.metrics.weighted_length > 280 ? "warning" : "good";
      return `
        <tr class="${selected}" data-id="${escapeHtml(post.id)}">
          <td>${escapeHtml(post.scheduled_at || "未排期")}</td>
          <td><span class="pill ${tone}">${escapeHtml(post.state_label)}</span></td>
          <td>${escapeHtml(post.id)}</td>
          <td>${escapeHtml(post.category)}</td>
          <td><span class="pill ${lengthTone}">${post.metrics.weighted_length}</span></td>
          <td class="summary-cell">${escapeHtml(post.summary)}</td>
        </tr>
      `;
    })
    .join("");
  els.postRows.querySelectorAll("tr[data-id]").forEach((row) => {
    row.addEventListener("click", () => {
      state.selectedId = row.dataset.id;
      renderTable(data);
      renderDetail(data.posts.find((post) => post.id === state.selectedId));
    });
  });
}

function renderDetail(post) {
  if (!post) {
    els.detailMeta.textContent = "选择一条内容";
    els.detailBody.textContent = "暂无选中内容。";
    els.detailTags.innerHTML = "";
    els.copyBtn.disabled = true;
    return;
  }
  state.selectedId = post.id;
  els.detailMeta.textContent = `${post.id} / ${post.state_label} / ${post.category} / X ${post.metrics.weighted_length}`;
  els.detailBody.textContent = post.text || "";
  const tags = [
    post.scheduled_at || "未排期",
    post.priority,
    post.source,
    post.assignee,
    post.platform,
    ...post.tags,
  ].filter(Boolean);
  els.detailTags.innerHTML = tags.map((tag) => `<span class="pill">${escapeHtml(tag)}</span>`).join("");
  els.copyBtn.disabled = false;
}

els.refreshBtn.addEventListener("click", () => loadDashboard(true));

els.queueTabs.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-queue]");
  if (!button) return;
  state.queue = button.dataset.queue;
  els.queueTabs.querySelectorAll("button").forEach((node) => node.classList.toggle("active", node === button));
  renderQueue(state.data);
});

els.searchInput.addEventListener("input", () => {
  state.filters.search = els.searchInput.value;
  renderTable(state.data);
});

els.statusFilter.addEventListener("change", () => {
  state.filters.status = els.statusFilter.value;
  renderTable(state.data);
});

els.categoryFilter.addEventListener("change", () => {
  state.filters.category = els.categoryFilter.value;
  renderTable(state.data);
});

els.riskOnly.addEventListener("change", () => {
  state.filters.riskOnly = els.riskOnly.checked;
  renderTable(state.data);
});

els.copyBtn.addEventListener("click", async () => {
  const post = state.data?.posts.find((item) => item.id === state.selectedId);
  if (!post) return;
  await navigator.clipboard.writeText(post.text || "");
  els.copyBtn.textContent = "已复制";
  setTimeout(() => {
    els.copyBtn.textContent = "复制全文";
  }, 1000);
});

loadDashboard(false);
