const state = {
  data: null,
  selectedId: null,
  queue: "today",
  filters: { search: "", status: "all", category: "all", riskOnly: false },
};

const stateClass = {
  draft: "warning", review: "warning", ready: "good",
  scheduled: "good", published: "", rejected: "danger", unknown: "",
};

const stateIcon = {
  draft: "\u270E", review: "\u23F3", ready: "\u2714",
  scheduled: "\uD83D\uDCC5", published: "\uD83D\uDCE4", rejected: "\u2716", unknown: "\u2753",
};

const els = {
  refreshBtn: document.querySelector("#refreshBtn"),
  reviewBtn: document.querySelector("#reviewBtn"),
  feishuLink: document.querySelector("#feishuLink"),
  statusStrip: document.querySelector("#statusStrip"),
  priorityLabel: document.querySelector("#priorityLabel"),
  priorityNote: document.querySelector("#priorityNote"),
  sourceLabel: document.querySelector("#sourceLabel"),
  configLabel: document.querySelector("#configLabel"),
  updatedAt: document.querySelector("#updatedAt"),
  warningBox: document.querySelector("#warningBox"),
  metricGrid: document.querySelector("#metricGrid"),
  categoryList: document.querySelector("#categoryList"),
  categoryBadge: document.querySelector("#categoryBadge"),
  riskList: document.querySelector("#riskList"),
  riskBadge: document.querySelector("#riskBadge"),
  timeline: document.querySelector("#timeline"),
  queueTabs: document.querySelector("#queueTabs"),
  queueList: document.querySelector("#queueList"),
  queueBadge: document.querySelector("#queueBadge"),
  searchInput: document.querySelector("#searchInput"),
  statusFilter: document.querySelector("#statusFilter"),
  categoryFilter: document.querySelector("#categoryFilter"),
  riskOnly: document.querySelector("#riskOnly"),
  postRows: document.querySelector("#postRows"),
  detailMeta: document.querySelector("#detailMeta"),
  detailBody: document.querySelector("#detailBody"),
  detailTags: document.querySelector("#detailTags"),
  copyBtn: document.querySelector("#copyBtn"),
  reviewModal: document.querySelector("#reviewModal"),
  modalBody: document.querySelector("#modalBody"),
  modalClose: document.querySelector("#modalClose"),
};

function esc(v) {
  return String(v ?? "").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
}

function pct(v, max) {
  return max ? Math.max(4, Math.min(100, Math.round((v / max) * 100))) : 0;
}

function isRisk(post) {
  return post.is_due || post.metrics.weighted_length > 280 || ((post.state === "ready" || post.state === "scheduled") && !post.scheduled_at);
}

function dashboardPriority(data) {
  const s = data.summary;
  if (s.due) return { tone: "danger", label: `${s.due} 条到点未处理`, note: "先清今日队列，避免发布节奏断档。" };
  if (s.publishable < data.targets.daily * 3) return { tone: "danger", label: `可发布仅 ${s.publishable_days} 天`, note: "优先审核或补排可直接发布内容。" };
  if (s.review >= data.targets.daily * 3) return { tone: "warning", label: `${s.review} 条待审核`, note: "内容池充足，瓶颈在审核转化。" };
  if (s.week_gap) return { tone: "warning", label: `7 天缺口 ${s.week_gap} 条`, note: "把可发布内容补进未来排期。" };
  return { tone: "good", label: "节奏稳定", note: "库存、排期和风险都在可控范围。" };
}

function getMetricIcon(key) {
  const map = {
    active_total: "\uD83D\uDCCA", publishable: "\uD83D\uDCE6", review: "\uD83D\uDC40",
    today_queue: "\uD83D\uDD14", week_queue: "\uD83D\uDCC5", long: "\uD83D\uDCD0",
  };
  return map[key] || "\uD83D\uDCC8";
}

async function loadDashboard(force = false) {
  els.refreshBtn.disabled = true;
  els.refreshBtn.innerHTML = force ? "\u{1F504} 刷新中" : "\u{1F504} 加载中";
  try {
    const r = await fetch(`/api/dashboard${force ? "?force=1" : ""}`, { cache: "no-store" });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const data = await r.json();
    if (data.ok === false) throw new Error(data.error || "数据加载失败");
    state.data = data;
    if (!state.selectedId && data.posts.length) state.selectedId = data.posts[0].id;
    render();
  } catch (e) {
    els.warningBox.hidden = false;
    els.warningBox.textContent = `\u{1F6A8} 看板加载失败：${e.message}`;
  } finally {
    els.refreshBtn.disabled = false;
    els.refreshBtn.innerHTML = "\u21BB 刷新数据";
  }
}

function render() {
  const d = state.data;
  if (!d) return;
  els.sourceLabel.textContent = d.source_label || "-";
  els.configLabel.textContent = d.config_summary || "-";
  els.updatedAt.textContent = d.generated_at || "-";
  const pri = dashboardPriority(d);
  els.priorityLabel.textContent = pri.label;
  els.priorityNote.textContent = pri.note;
  els.statusStrip.dataset.priority = pri.tone;
  els.feishuLink.style.display = d.base_url ? "" : "none";
  if (d.base_url) els.feishuLink.href = d.base_url;
  if (d.warning) {
    els.warningBox.hidden = false;
    els.warningBox.innerHTML = `\u26A0\uFE0F ${esc(d.warning)}`;
  } else {
    els.warningBox.hidden = true;
  }
  renderMetrics(d);
  renderCategories(d);
  renderRisks(d);
  renderTimeline(d);
  renderQueue(d);
  renderFilters(d);
  renderTable(d);
  renderDetail(d.posts.find(p => p.id === state.selectedId) || d.posts[0]);
}

const metricDefs = [
  { key: "active_total", label: "内容池总量", get: s => s.active_total, hint: s => `全部 ${s.total} 条，已发布 ${s.published}`, tone: (s, t) => "good" },
  { key: "publishable", label: "可发布库存", get: s => s.publishable, hint: (s, t) => `约 ${s.publishable_days} 天库存`, tone: (s, t) => s.publishable < t.daily * 3 ? "danger" : "good" },
  { key: "review", label: "待审核", get: s => s.review, hint: () => "需要审核转入发布池", tone: s => s.review ? "warning" : "" },
  { key: "today_queue", label: "今日队列", get: s => s.today_queue, hint: s => `到点 ${s.due} 条`, tone: s => s.due ? "danger" : "" },
  { key: "week_queue", label: "7 天排期", get: s => s.week_queue, hint: s => `缺口 ${s.week_gap} 条`, tone: s => s.week_gap ? "warning" : "good" },
  { key: "long", label: "长度风险", get: s => s.long, hint: () => "超过普通 X 帖限制", tone: s => s.long ? "warning" : "" },
];

function renderMetrics(data) {
  els.metricGrid.innerHTML = metricDefs.map(m => {
    const v = m.get(data.summary);
    const h = m.hint(data.summary, data.targets);
    const t = m.tone(data.summary, data.targets);
    const icon = getMetricIcon(m.key);
    return `
      <article class="metric-card ${t}">
        <div class="metric-topline">
          <div class="metric-icon">${icon}</div>
          <div class="label">${esc(m.label)}</div>
        </div>
        <div class="value">${esc(v)}</div>
        <div class="hint">${esc(h)}</div>
      </article>
    `;
  }).join("");
}

function renderCategories(data) {
  const cats = data.category_stats;
  els.categoryBadge.textContent = cats.length;
  els.categoryList.innerHTML = cats.map(r => {
    const hp = r.health === "low" ? "danger" : r.health === "review" ? "warning" : "good";
    const hl = r.health === "low" ? "可发不足" : r.health === "review" ? "待审核多" : "稳定";
    return `
      <div class="category-row ${esc(r.health)}">
        <div>
          <div class="category-name">${esc(r.category)}</div>
          <span class="muted">活跃 ${r.active} / 总 ${r.total}</span>
        </div>
        ${categoryBar(r)}
        <div class="category-counts">
          <span class="pill good">可发 ${r.publishable}</span>
          <span class="pill warning">待审 ${r.review}</span>
          <span class="pill teal">已排 ${r.scheduled}</span>
          <span class="pill ${hp}">${hl}</span>
        </div>
      </div>
    `;
  }).join("");
}

function categoryBar(row) {
  const other = Math.max(0, row.active - row.ready - row.scheduled - row.review);
  const segs = [
    { key: "ready", label: `可发布 ${row.ready}`, v: row.ready },
    { key: "scheduled", label: `已安排 ${row.scheduled}`, v: row.scheduled },
    { key: "review", label: `待审核 ${row.review}`, v: row.review },
    { key: "draft", label: `其他 ${other}`, v: other },
  ].filter(s => s.v > 0);
  if (!segs.length) return '<div class="bar-track category-track"><div class="bar-fill draft" style="flex-grow:1"></div></div>';
  return `<div class="bar-track category-track">${segs.map(s => `<div class="bar-fill ${s.key}" style="flex-grow:${s.v}" title="${esc(s.label)}"></div>`).join("")}</div>`;
}

function renderRisks(data) {
  const risks = data.risks;
  els.riskBadge.textContent = risks.filter(r => r.level !== "ok").length;
  els.riskList.innerHTML = risks.map(r => `
    <div class="risk-row ${esc(r.level)}">
      <div class="risk-title">
        <span>${esc(r.title)}</span>
        <span class="risk-count">${r.count || "OK"}</span>
      </div>
      <div class="risk-detail">${esc(r.detail)}</div>
    </div>
  `).join("");
}

function renderTimeline(data) {
  const daily = data.targets.daily;
  els.timeline.innerHTML = data.timeline.map(d => `
    <div class="day-row">
      <div>
        <div class="day-date">${esc(d.label)}</div>
        <span class="muted">${esc(d.date)}</span>
      </div>
      <div class="bar-track">
        <div class="bar-fill ${d.count < daily ? "review" : ""}" style="width:${pct(d.count, daily)}%"></div>
      </div>
      <div class="day-gap">${d.count}/${daily}<br>缺 ${d.gap}</div>
    </div>
  `).join("");
}

function renderQueue(data) {
  const rows = data.queues[state.queue] || [];
  const total = data.summary;
  const counts = { today: total.today_queue, week: total.week_queue, review: total.review, ready: total.publishable, risk: total.due + total.long };
  els.queueBadge.textContent = counts[state.queue] || 0;
  if (!rows.length) {
    els.queueList.innerHTML = '<div class="empty">\u{1F4ED} 当前队列为空。</div>';
    return;
  }
  els.queueList.innerHTML = rows.map(queueRow).join("");
  els.queueList.querySelectorAll("[data-id]").forEach(n => {
    n.addEventListener("click", () => {
      state.selectedId = n.dataset.id;
      renderQueue(data);
      renderTable(data);
      renderDetail(data.posts.find(p => p.id === state.selectedId));
    });
  });
}

function queueRow(post) {
  const tone = stateClass[post.state] || "";
  const sel = post.id === state.selectedId ? "selected" : "";
  return `
    <div class="queue-row ${sel}" data-id="${esc(post.id)}">
      <div class="queue-time">${esc(post.scheduled_at || "未排期")}</div>
      <div><span class="pill ${tone}">${stateIcon[post.state] || ""} ${esc(post.state_label)}</span></div>
      <div class="queue-summary">
        <strong>${esc(post.id)} \u00B7 ${esc(post.category)}</strong>
        <span>${esc(post.summary)}</span>
        <div class="queue-meta">${esc(post.assignee)} / ${esc(post.source)} / ${esc(post.platform)}</div>
      </div>
      <div class="queue-meta">X ${post.metrics.weighted_length}</div>
    </div>
  `;
}

function renderFilters(data) {
  const cs = state.filters.status, cc = state.filters.category;
  const statuses = [{ value: "all", label: "全部状态" }, ...data.status_counts.map(s => ({ value: s.state, label: s.label }))];
  const cats = [{ value: "all", label: "全部分类" }, ...data.category_stats.map(c => ({ value: c.category, label: c.category }))];
  els.statusFilter.innerHTML = statuses.map(s => `<option value="${esc(s.value)}">${esc(s.label)}</option>`).join("");
  els.categoryFilter.innerHTML = cats.map(c => `<option value="${esc(c.value)}">${esc(c.label)}</option>`).join("");
  els.statusFilter.value = cs;
  els.categoryFilter.value = cc;
}

function filteredPosts(data) {
  const kw = state.filters.search.trim().toLowerCase();
  return data.posts.filter(p => {
    if (state.filters.status !== "all" && p.state !== state.filters.status) return false;
    if (state.filters.category !== "all" && p.category !== state.filters.category) return false;
    if (state.filters.riskOnly && !isRisk(p)) return false;
    if (!kw) return true;
    const blob = [p.id, p.status, p.category, p.tags_text, p.assignee, p.summary, p.text].join(" ").toLowerCase();
    return blob.includes(kw);
  });
}

function renderTable(data) {
  const rows = filteredPosts(data);
  if (!rows.length) {
    els.postRows.innerHTML = '<tr><td colspan="6" class="empty">没有符合筛选条件的内容。</td></tr>';
    return;
  }
  els.postRows.innerHTML = rows.slice(0, 240).map(p => {
    const tone = stateClass[p.state] || "";
    const sel = p.id === state.selectedId ? "selected" : "";
    const lt = p.metrics.weighted_length > 280 ? "warning" : "good";
    return `
      <tr class="${sel}" data-id="${esc(p.id)}">
        <td>${esc(p.scheduled_at || "未排期")}</td>
        <td><span class="pill ${tone}">${stateIcon[p.state] || ""} ${esc(p.state_label)}</span></td>
        <td>${esc(p.id)}</td>
        <td>${esc(p.category)}</td>
        <td><span class="pill ${lt}">${p.metrics.weighted_length}</span></td>
        <td class="summary-cell">${esc(p.summary)}</td>
      </tr>
    `;
  }).join("");
  els.postRows.querySelectorAll("tr[data-id]").forEach(row => {
    row.addEventListener("click", () => {
      state.selectedId = row.dataset.id;
      renderQueue(data);
      renderTable(data);
      renderDetail(data.posts.find(p => p.id === state.selectedId));
    });
  });
}

function renderDetail(post) {
  if (!post) {
    els.detailMeta.textContent = "选择一条内容";
    els.detailBody.textContent = "暂无选中内容。";
    els.detailTags.innerHTML = "";
    els.copyBtn.disabled = true;
    return;
  }
  state.selectedId = post.id;
  const tone = stateClass[post.state] || "";
  const lt = post.metrics.weighted_length > 280 ? "warning" : "good";
  els.detailMeta.innerHTML = `
    <span>${esc(post.id)}</span>
    <span class="pill ${tone}">${stateIcon[post.state] || ""} ${esc(post.state_label)}</span>
    <span class="pill teal">${esc(post.category)}</span>
    <span class="pill ${lt}">X ${post.metrics.weighted_length}</span>
  `;
  els.detailBody.textContent = post.text || "";
  const tags = [post.scheduled_at || "未排期", post.priority, post.source, post.assignee, post.platform, ...post.tags].filter(Boolean);
  els.detailTags.innerHTML = tags.map(t => `<span class="pill">${esc(t)}</span>`).join("");
  els.copyBtn.disabled = false;
}

function renderModal() {
  const d = state.data;
  if (!d) { els.modalBody.innerHTML = '<p class="empty">暂无数据</p>'; return; }
  const s = d.summary;
  const pri = dashboardPriority(d);
  const toneLabel = { danger: "danger", warning: "warning", good: "good" }[pri.tone] || "";

  const riskItems = d.risks.filter(r => r.level !== "ok").map(r => `
    <li>
      <span>${esc(r.title)}</span>
      <span class="${r.level === "high" ? "danger" : r.level === "medium" ? "warning" : ""}">${r.count} 项</span>
    </li>
  `).join("");

  const catItems = d.category_stats.filter(c => c.health !== "ok").map(c => `
    <li>
      <span>${esc(c.category)}</span>
      <span class="${c.health === "low" ? "danger" : "warning"}">${c.health === "low" ? "可发布不足" : "待审核积压"}</span>
    </li>
  `).join("");

  els.modalBody.innerHTML = `
    <div class="modal-section">
      <h3>\u{1F4CA} 运营总览</h3>
      <div class="modal-grid">
        <div class="modal-stat">
          <div class="modal-stat-label">运营状态</div>
          <div class="modal-stat-value ${toneLabel}">${esc(pri.label)}</div>
        </div>
        <div class="modal-stat">
          <div class="modal-stat-label">内容总量</div>
          <div class="modal-stat-value">${s.total}</div>
        </div>
        <div class="modal-stat">
          <div class="modal-stat-label">活跃内容</div>
          <div class="modal-stat-value">${s.active_total}</div>
        </div>
        <div class="modal-stat">
          <div class="modal-stat-label">可发布</div>
          <div class="modal-stat-value ${s.publishable < d.targets.daily * 3 ? "danger" : "good"}">${s.publishable}</div>
        </div>
        <div class="modal-stat">
          <div class="modal-stat-label">待审核</div>
          <div class="modal-stat-value ${s.review ? "warning" : ""}">${s.review}</div>
        </div>
        <div class="modal-stat">
          <div class="modal-stat-label">已发布</div>
          <div class="modal-stat-value">${s.published}</div>
        </div>
        <div class="modal-stat">
          <div class="modal-stat-label">今日队列</div>
          <div class="modal-stat-value ${s.due ? "danger" : ""}">${s.today_queue}</div>
        </div>
        <div class="modal-stat">
          <div class="modal-stat-label">7 天缺口</div>
          <div class="modal-stat-value ${s.week_gap ? "warning" : "good"}">${s.week_gap}</div>
        </div>
      </div>
    </div>
    ${riskItems ? `
    <div class="modal-section">
      <h3>\u26A0\uFE0F 待处理风险</h3>
      <ul class="modal-list">${riskItems}</ul>
    </div>` : ""}
    ${catItems ? `
    <div class="modal-section">
      <h3>\uD83D\uDCC1 需关注分类</h3>
      <ul class="modal-list">${catItems}</ul>
    </div>` : ""}
    <div class="modal-section">
      <h3>\uD83D\uDCC5 排期概览</h3>
      <ul class="modal-list">
        ${d.timeline.map(t => `<li><span>${esc(t.label)} (${esc(t.date)})</span><span>${t.count} / ${d.targets.daily} ${t.gap > 0 ? `\u{1F538} 缺 ${t.gap}` : "\u2705"}</span></li>`).join("")}
      </ul>
    </div>
    <div class="modal-section">
      <h3>\uD83D\uDCCB 分类分布</h3>
      <ul class="modal-list">
        ${d.category_stats.map(c => `<li><span>${esc(c.category)}</span><span>可发 ${c.publishable} / 待审 ${c.review} / 活跃 ${c.active}</span></li>`).join("")}
      </ul>
    </div>
    <div class="modal-section">
      <h3>\uD83D\uDC64 负责人负载</h3>
      <ul class="modal-list">
        ${d.assignee_stats.map(a => `<li><span>${esc(a.assignee)}</span><span>${a.total} 条${a.review ? ` / 待审 ${a.review}` : ""}${a.published ? ` / 已发 ${a.published}` : ""}</span></li>`).join("")}
      </ul>
    </div>
  `;
}

function openModal() {
  renderModal();
  els.reviewModal.classList.add("open");
  document.body.style.overflow = "hidden";
}

function closeModal() {
  els.reviewModal.classList.remove("open");
  document.body.style.overflow = "";
}

els.refreshBtn.addEventListener("click", () => loadDashboard(true));
els.reviewBtn.addEventListener("click", openModal);
els.modalClose.addEventListener("click", closeModal);
els.reviewModal.addEventListener("click", e => { if (e.target === els.reviewModal) closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

els.queueTabs.addEventListener("click", e => {
  const btn = e.target.closest("button[data-queue]");
  if (!btn) return;
  state.queue = btn.dataset.queue;
  els.queueTabs.querySelectorAll("button").forEach(n => n.classList.toggle("active", n === btn));
  renderQueue(state.data);
});

els.searchInput.addEventListener("input", () => {
  state.filters.search = els.searchInput.value;
  renderTable(state.data);
});

els.statusFilter.addEventListener("change", () => {
  state.filters.status = els.statusFilter.value;
  renderTable(state.data);
});

els.categoryFilter.addEventListener("change", () => {
  state.filters.category = els.categoryFilter.value;
  renderTable(state.data);
});

els.riskOnly.addEventListener("change", () => {
  state.filters.riskOnly = els.riskOnly.checked;
  renderTable(state.data);
});

els.copyBtn.addEventListener("click", async () => {
  const post = state.data?.posts.find(p => p.id === state.selectedId);
  if (!post) return;
  try {
    await navigator.clipboard.writeText(post.text || "");
    els.copyBtn.textContent = "\u2705 已复制";
  } catch {
    els.copyBtn.textContent = "\u274C 复制失败";
  }
  setTimeout(() => { els.copyBtn.textContent = "复制全文"; }, 1200);
});

loadDashboard(false);
