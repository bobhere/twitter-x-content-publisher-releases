import csv
import json
import re
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any


LOCAL_CSV_FILE = "posts.csv"
CACHE_CSV_FILE = "posts_cache.csv"
FEISHU_CONFIG_FILE = "feishu_config.json"

STANDARD_LIMIT = 280
LONG_POST_LIMIT = 25000

REQUIRED_COLUMNS = [
    "id",
    "record_id",
    "scheduled_at",
    "text",
    "status",
    "category",
    "tags",
    "language",
    "priority",
    "source",
    "assignee",
    "posted_at",
    "notes",
]

SCHEDULED_STATUSES = {
    "",
    "draft",
    "pending",
    "ready",
    "scheduled",
    "待发布",
    "可发布",
    "已安排",
}

DONE_STATUSES = {"posted", "已发布"}
REJECTED_STATUSES = {"skipped", "rejected", "archived", "作废", "归档"}

DEFAULT_FIELD_MAP = {
    "id": "编号",
    "text": "文案正文",
    "scheduled_at": "计划发布时间",
    "status": "状态",
    "category": "分类",
    "tags": "标签",
    "language": "语言",
    "priority": "优先级",
    "source": "来源",
    "assignee": "负责人",
    "posted_at": "实际发布时间",
    "notes": "备注",
}


@dataclass
class TextMetrics:
    visible_length: int
    weighted_length: int
    url_count: int
    line_count: int

    @property
    def label(self) -> str:
        if self.weighted_length <= STANDARD_LIMIT:
            return f"普通帖可发，还剩 {STANDARD_LIMIT - self.weighted_length}"
        if self.weighted_length <= LONG_POST_LIMIT:
            return "超过普通帖，建议拆 thread 或使用 Premium 长文"
        return "超过 X 长文上限，需要删减"


@dataclass
class Post:
    row_index: int
    data: dict[str, str]
    scheduled_at: datetime | None
    raw_scheduled_at: str
    record_id: str = ""

    @property
    def post_id(self) -> str:
        return self.data.get("id", "").strip() or self.record_id or f"row-{self.row_index + 1}"

    @property
    def text(self) -> str:
        return self.data.get("text", "")

    @property
    def status(self) -> str:
        return self.data.get("status", "").strip()

    @property
    def normalized_status(self) -> str:
        return self.status.lower() if is_ascii(self.status) else self.status

    @property
    def category(self) -> str:
        return self.data.get("category", "").strip()

    @property
    def tags(self) -> str:
        return self.data.get("tags", "").strip()

    @property
    def priority(self) -> str:
        return self.data.get("priority", "").strip()

    @property
    def source(self) -> str:
        return self.data.get("source", "").strip()

    @property
    def assignee(self) -> str:
        return self.data.get("assignee", "").strip()

    @property
    def is_scheduled(self) -> bool:
        return self.normalized_status in SCHEDULED_STATUSES

    @property
    def is_due(self) -> bool:
        return self.is_scheduled and self.scheduled_at is not None and self.scheduled_at <= datetime.now()

    @property
    def metrics(self) -> TextMetrics:
        return calculate_x_metrics(self.text)


@dataclass
class StoreResult:
    posts: list[Post]
    source_label: str
    warning: str = ""


class StoreError(Exception):
    pass


class CsvPostStore:
    def __init__(self, csv_path: Path):
        self.csv_path = csv_path
        self.rows: list[dict[str, str]] = []
        self.columns = REQUIRED_COLUMNS.copy()

    def ensure_exists(self) -> None:
        if self.csv_path.exists():
            return
        self.rows = [
            {
                "id": "001",
                "record_id": "",
                "scheduled_at": "2099-01-01 10:00",
                "text": "这里写第一条纯文字 Twitter。到点后点击“准备发布”，程序会复制这段文字并打开 X 发帖页。",
                "status": "可发布",
                "category": "观点",
                "tags": "示例",
                "language": "zh-CN",
                "priority": "中",
                "source": "人工",
                "assignee": "",
                "posted_at": "",
                "notes": "纯文字示例",
            },
            {
                "id": "002",
                "record_id": "",
                "scheduled_at": "2099-01-01 10:30",
                "text": "这是一条中长文案示例。右侧会展示全文、普通字数、X 加权长度，以及是否超出普通帖 280 的限制。",
                "status": "待审核",
                "category": "产品",
                "tags": "示例;中长",
                "language": "zh-CN",
                "priority": "低",
                "source": "AI",
                "assignee": "",
                "posted_at": "",
                "notes": "中长文案示例",
            },
        ]
        self.save()

    def load(self) -> list[Post]:
        self.ensure_exists()
        with self.csv_path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            fieldnames = reader.fieldnames or []
            self.columns = merge_columns(fieldnames, REQUIRED_COLUMNS)
            self.rows = []
            for row in reader:
                self.rows.append({column: row.get(column, "") for column in self.columns})
        return self.posts()

    def posts(self) -> list[Post]:
        posts = []
        for index, row in enumerate(self.rows):
            raw = row.get("scheduled_at", "")
            posts.append(
                Post(
                    row_index=index,
                    data=row,
                    scheduled_at=parse_datetime(raw),
                    raw_scheduled_at=format_datetime_value(raw),
                    record_id=row.get("record_id", ""),
                )
            )
        return posts

    def update_post(self, post: Post, values: dict[str, str]) -> None:
        self.load()
        target_index = post.row_index
        if target_index < 0 or target_index >= len(self.rows):
            target_index = find_row_index(self.rows, post)
        if target_index < 0:
            raise StoreError("本地缓存中找不到这条内容，无法更新。")
        for key, value in values.items():
            if key not in self.columns:
                self.columns.append(key)
            self.rows[target_index][key] = value
        self.save()

    def replace_posts(self, posts: list[Post]) -> None:
        self.rows = []
        self.columns = REQUIRED_COLUMNS.copy()
        for post in posts:
            row = {column: post.data.get(column, "") for column in self.columns}
            row["record_id"] = post.record_id
            self.rows.append(row)
        self.save()

    def save(self) -> None:
        self.csv_path.parent.mkdir(parents=True, exist_ok=True)
        with self.csv_path.open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=self.columns)
            writer.writeheader()
            for row in self.rows:
                writer.writerow({column: row.get(column, "") for column in self.columns})


class FeishuConfig:
    def __init__(self, path: Path):
        self.path = path
        self.enabled = False
        self.auth_mode = "api"
        self.api_base = "https://open.feishu.cn/open-apis"
        self.app_id = ""
        self.app_secret = ""
        self.base_token = ""
        self.table_id = ""
        self.view_id = ""
        self.page_size = 100
        self.lark_cli_identity = "bot"
        self.browser_preference = "chrome"
        self.base_url = ""
        self.auto_sync_minutes = 60
        self.field_map = DEFAULT_FIELD_MAP.copy()

    def load(self) -> "FeishuConfig":
        if not self.path.exists():
            return self
        with self.path.open("r", encoding="utf-8") as f:
            raw = json.load(f)
        self.enabled = parse_bool(raw.get("enabled", False))
        self.auth_mode = str(raw.get("auth_mode", self.auth_mode)).strip() or "api"
        self.api_base = str(raw.get("api_base", self.api_base)).rstrip("/")
        self.app_id = str(raw.get("app_id", "")).strip()
        self.app_secret = str(raw.get("app_secret", "")).strip()
        self.base_token = str(raw.get("base_token") or raw.get("app_token") or "").strip()
        self.table_id = str(raw.get("table_id", "")).strip()
        self.view_id = str(raw.get("view_id", "")).strip()
        self.browser_preference = str(raw.get("browser_preference", self.browser_preference)).strip() or "chrome"
        self.base_url = str(raw.get("base_url", "")).strip()
        try:
            self.auto_sync_minutes = int(raw.get("auto_sync_minutes", self.auto_sync_minutes) or self.auto_sync_minutes)
        except (TypeError, ValueError):
            self.auto_sync_minutes = 60
        try:
            self.page_size = int(raw.get("page_size", self.page_size) or self.page_size)
        except (TypeError, ValueError):
            self.page_size = 100
        self.lark_cli_identity = str(raw.get("lark_cli_identity", self.lark_cli_identity)).strip() or "bot"
        self.field_map = DEFAULT_FIELD_MAP.copy()
        self.field_map.update(raw.get("field_map", {}) or {})
        return self

    @property
    def is_ready(self) -> bool:
        if not self.enabled:
            return False
        if self.use_lark_cli:
            return all([self.base_token, self.table_id])
        return all([self.app_id, self.app_secret, self.base_token, self.table_id])

    @property
    def use_lark_cli(self) -> bool:
        return self.auth_mode.lower() in {"lark_cli", "cli"}

    @property
    def safe_summary(self) -> str:
        if not self.enabled:
            return "飞书未启用"
        if self.use_lark_cli and self.is_ready:
            return f"飞书 CLI：{mask_token(self.base_token)} / {self.table_id}"
        if not self.is_ready:
            return "飞书配置不完整"
        return f"飞书已启用：{mask_token(self.base_token)} / {self.table_id}"


class FeishuClient:
    def __init__(self, config: FeishuConfig):
        self.config = config
        self._tenant_token = ""
        self._token_expires_at = 0.0

    def test_connection(self) -> str:
        token = self.get_tenant_token()
        if not token:
            raise StoreError("没有拿到 tenant_access_token。")
        query = {"page_size": 1}
        if self.config.view_id:
            query["view_id"] = self.config.view_id
        path = f"/bitable/v1/apps/{self.config.base_token}/tables/{self.config.table_id}/records"
        self.request_raw("GET", path, query=query)
        return "飞书连接成功，应用凭证和表格权限可用。"

    def get_tenant_token(self) -> str:
        now = time.time()
        if self._tenant_token and now < self._token_expires_at - 60:
            return self._tenant_token
        payload = {
            "app_id": self.config.app_id,
            "app_secret": self.config.app_secret,
        }
        data = self.request_raw("POST", "/auth/v3/tenant_access_token/internal", payload, auth=False)
        token = data.get("tenant_access_token", "")
        if not token:
            raise StoreError(f"飞书认证失败：{data}")
        self._tenant_token = token
        self._token_expires_at = now + int(data.get("expire", 7200))
        return token

    def list_records(self) -> list[dict[str, Any]]:
        records = []
        page_token = ""
        while True:
            query = {"page_size": max(20, min(self.config.page_size, 500))}
            if self.config.view_id:
                query["view_id"] = self.config.view_id
            if page_token:
                query["page_token"] = page_token
            path = f"/bitable/v1/apps/{self.config.base_token}/tables/{self.config.table_id}/records"
            data = self.request_raw("GET", path, query=query)
            block = data.get("data", {})
            records.extend(block.get("items", []) or [])
            if not block.get("has_more"):
                break
            page_token = block.get("page_token", "")
            if not page_token:
                break
        return records

    def update_record(self, record_id: str, fields: dict[str, Any]) -> None:
        path = f"/bitable/v1/apps/{self.config.base_token}/tables/{self.config.table_id}/records/{record_id}"
        payload = {"fields": fields}
        self.request_raw("PUT", path, payload)

    def create_record(self, fields: dict[str, Any]) -> str:
        path = f"/bitable/v1/apps/{self.config.base_token}/tables/{self.config.table_id}/records"
        payload = {"fields": fields}
        data = self.request_raw("POST", path, payload)
        record = data.get("data", {}).get("record", {})
        return record.get("record_id", "")

    def request_raw(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        query: dict[str, Any] | None = None,
        auth: bool = True,
    ) -> dict[str, Any]:
        url = self.config.api_base + path
        if query:
            url += "?" + urllib.parse.urlencode(query)
        headers = {"Content-Type": "application/json; charset=utf-8"}
        if auth:
            headers["Authorization"] = f"Bearer {self.get_tenant_token()}"
        body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(url, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                raw = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise StoreError(f"飞书 API HTTP {exc.code}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise StoreError(f"无法连接飞书 API：{exc.reason}") from exc
        data = json.loads(raw or "{}")
        code = int(data.get("code", 0) or 0)
        if code != 0:
            raise StoreError(f"飞书 API 返回错误 code={code}: {data.get('msg') or data}")
        return data


class LarkCliClient:
    def __init__(self, config: FeishuConfig):
        self.config = config

    def test_connection(self) -> str:
        self.list_records(limit=1)
        return "飞书 CLI 连接成功，Base 读取权限可用。"

    def list_records(self, limit: int | None = None) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        offset = 0
        page_size = max(1, min(limit or self.config.page_size, 200))
        while True:
            args = [
                "lark-cli",
                "base",
                "+record-list",
                "--as",
                self.config.lark_cli_identity,
                "--base-token",
                self.config.base_token,
                "--table-id",
                self.config.table_id,
                "--offset",
                str(offset),
                "--limit",
                str(page_size),
            ]
            if self.config.view_id:
                args.extend(["--view-id", self.config.view_id])
            data = self.run_json(args)
            block = data.get("data", {})
            fields = block.get("fields", []) or []
            rows = block.get("data", []) or []
            record_ids = block.get("record_id_list", []) or []
            for index, values in enumerate(rows):
                row_fields = {}
                for field_index, field_name in enumerate(fields):
                    row_fields[field_name] = values[field_index] if field_index < len(values) else ""
                records.append(
                    {
                        "record_id": record_ids[index] if index < len(record_ids) else "",
                        "fields": row_fields,
                    }
                )
            if limit is not None or not block.get("has_more") or not rows:
                break
            offset += len(rows)
        return records

    def update_record(self, record_id: str, fields: dict[str, Any]) -> None:
        args = [
            "lark-cli",
            "base",
            "+record-upsert",
            "--as",
            self.config.lark_cli_identity,
            "--base-token",
            self.config.base_token,
            "--table-id",
            self.config.table_id,
            "--record-id",
            record_id,
            "--json",
            json.dumps(fields, ensure_ascii=False),
        ]
        self.run_json(args)

    def create_record(self, fields: dict[str, Any]) -> str:
        args = [
            "lark-cli",
            "base",
            "+record-upsert",
            "--as",
            self.config.lark_cli_identity,
            "--base-token",
            self.config.base_token,
            "--table-id",
            self.config.table_id,
            "--json",
            json.dumps(fields, ensure_ascii=False),
        ]
        data = self.run_json(args)
        record = data.get("data", {}).get("record", {})
        return record.get("record_id", "")

    def run_json(self, args: list[str]) -> dict[str, Any]:
        try:
            result = subprocess.run(args, text=True, capture_output=True, timeout=45)
        except FileNotFoundError as exc:
            raise StoreError("未找到 lark-cli，请先安装并完成配置。") from exc
        except subprocess.TimeoutExpired as exc:
            raise StoreError("lark-cli 调用超时。") from exc
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "").strip()
            raise StoreError(f"lark-cli 调用失败：{detail}")
        try:
            data = json.loads(result.stdout or "{}")
        except json.JSONDecodeError as exc:
            raise StoreError(f"lark-cli 返回内容不是 JSON：{result.stdout[:500]}") from exc
        if data.get("ok") is False or int(data.get("code", 0) or 0) != 0:
            raise StoreError(f"lark-cli 返回错误：{data.get('msg') or data}")
        return data


class FeishuPostStore:
    def __init__(self, base_dir: Path):
        self.base_dir = base_dir
        self.config = FeishuConfig(base_dir / FEISHU_CONFIG_FILE).load()
        self.cache = CsvPostStore(base_dir / CACHE_CSV_FILE)
        self.local = CsvPostStore(base_dir / LOCAL_CSV_FILE)
        self.client = LarkCliClient(self.config) if self.config.use_lark_cli else FeishuClient(self.config)
        self.last_source_label = "本地示例"
        self.last_warning = ""
        self._last_posts: list[Post] = []
        self._lock = threading.RLock()

    def load(self) -> StoreResult:
        with self._lock:
            if not self.config.is_ready:
                posts = self.local.load()
                self._last_posts = posts
                warning = self.config.safe_summary if self.config.enabled else ""
                return StoreResult(posts=posts, source_label="本地示例", warning=warning)
            try:
                posts = self.load_from_feishu()
                self.cache.replace_posts(posts)
                self._last_posts = posts
                self.last_source_label = "飞书多维表格"
                self.last_warning = ""
                return StoreResult(posts=posts, source_label=self.last_source_label)
            except StoreError as exc:
                try:
                    posts = self.cache.load()
                    warning = f"飞书读取失败，已使用本地缓存：{exc}"
                    self._last_posts = posts
                    self.last_source_label = "本地缓存"
                    self.last_warning = warning
                    return StoreResult(posts=posts, source_label=self.last_source_label, warning=warning)
                except Exception:
                    posts = self.local.load()
                    warning = f"飞书读取失败，且没有可用缓存：{exc}"
                    self._last_posts = posts
                    self.last_source_label = "本地示例"
                    self.last_warning = warning
                    return StoreResult(posts=posts, source_label=self.last_source_label, warning=warning)

    def load_from_feishu(self) -> list[Post]:
        records = self.client.list_records()
        posts = []
        for index, record in enumerate(records):
            fields = record.get("fields", {}) or {}
            row = feishu_fields_to_row(fields, self.config.field_map)
            record_id = record.get("record_id", "")
            row["record_id"] = record_id
            if not row.get("id"):
                row["id"] = record_id
            raw_schedule = row.get("scheduled_at", "")
            posts.append(
                Post(
                    row_index=index,
                    data=row,
                    scheduled_at=parse_datetime(raw_schedule),
                    raw_scheduled_at=format_datetime_value(raw_schedule),
                    record_id=record_id,
                )
            )
        return posts

    def update_post(self, post: Post, values: dict[str, str]) -> None:
        with self._lock:
            if self.config.is_ready and self.last_source_label == "飞书多维表格" and post.record_id:
                fields = row_values_to_cli_fields(values, self.config.field_map) if self.config.use_lark_cli else row_values_to_feishu_fields(values, self.config.field_map)
                self.client.update_record(post.record_id, fields)
                return
            target_store = self.cache if self.last_source_label == "本地缓存" else self.local
            target_store.update_post(post, values)

    def create_post(self, row: dict[str, str]) -> str:
        with self._lock:
            if self.config.is_ready:
                fields = row_values_to_cli_fields(row, self.config.field_map) if self.config.use_lark_cli else row_values_to_feishu_fields(row, self.config.field_map)
                return self.client.create_record(fields)
            self.local.load()
            self.local.rows.append({column: row.get(column, "") for column in self.local.columns})
            self.local.save()
            return ""

    def test_connection(self) -> str:
        with self._lock:
            if not self.config.is_ready:
                raise StoreError("请先复制 feishu_config.example.json 为 feishu_config.json，并填写 app_id、app_secret、base_token、table_id。")
            return self.client.test_connection()


def feishu_fields_to_row(fields: dict[str, Any], field_map: dict[str, str]) -> dict[str, str]:
    row = {column: "" for column in REQUIRED_COLUMNS}
    for key, field_name in field_map.items():
        if key not in row:
            continue
        row[key] = normalize_display_value(fields.get(field_name, ""))
    return row


def row_values_to_feishu_fields(values: dict[str, str], field_map: dict[str, str]) -> dict[str, Any]:
    fields: dict[str, Any] = {}
    for key, value in values.items():
        field_name = field_map.get(key)
        if not field_name:
            continue
        if key in {"scheduled_at", "posted_at"}:
            parsed = parse_datetime(value)
            fields[field_name] = int(parsed.timestamp() * 1000) if parsed else value
        else:
            fields[field_name] = value
    return fields


def row_values_to_cli_fields(values: dict[str, str], field_map: dict[str, str]) -> dict[str, Any]:
    fields: dict[str, Any] = {}
    for key, value in values.items():
        field_name = field_map.get(key)
        if not field_name:
            continue
        fields[field_name] = value
    return fields


def find_row_index(rows: list[dict[str, str]], post: Post) -> int:
    for index, row in enumerate(rows):
        if row.get("record_id") and row.get("record_id") == post.record_id:
            return index
        if row.get("id") and row.get("id") == post.post_id:
            return index
    return -1


def merge_columns(existing: list[str], required: list[str]) -> list[str]:
    columns = []
    for column in existing + required:
        if column and column not in columns:
            columns.append(column)
    return columns


def parse_datetime(value: Any) -> datetime | None:
    raw = normalize_display_value(value).strip()
    if not raw:
        return None
    if raw.isdigit() and len(raw) >= 10:
        timestamp = int(raw)
        if timestamp > 9999999999:
            timestamp = timestamp // 1000
        try:
            return datetime.fromtimestamp(timestamp)
        except (ValueError, OSError):
            return None
    candidates = [raw, raw.replace("T", " ")]
    formats = [
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d %H:%M:%S",
        "%Y/%m/%d %H:%M",
        "%Y/%m/%d %H:%M:%S",
        "%Y-%m-%d",
        "%Y/%m/%d",
    ]
    for candidate in candidates:
        for fmt in formats:
            try:
                return datetime.strptime(candidate, fmt)
            except ValueError:
                pass
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            pass
    return None


def format_datetime_value(value: Any) -> str:
    parsed = parse_datetime(value)
    if parsed:
        return parsed.strftime("%Y-%m-%d %H:%M")
    return normalize_display_value(value)


URL_RE = re.compile(r"https?://[^\s]+|www\.[^\s]+", re.IGNORECASE)


def calculate_x_metrics(text: str) -> TextMetrics:
    text = text or ""
    weighted = 0
    url_count = 0
    cursor = 0
    for match in URL_RE.finditer(text):
        weighted += weighted_text_length(text[cursor : match.start()])
        weighted += 23
        url_count += 1
        cursor = match.end()
    weighted += weighted_text_length(text[cursor:])
    return TextMetrics(
        visible_length=len(text),
        weighted_length=weighted,
        url_count=url_count,
        line_count=0 if not text else text.count("\n") + 1,
    )


def weighted_text_length(text: str) -> int:
    total = 0
    skip_joiner = False
    for char in text:
        code = ord(char)
        if char == "\u200d":
            skip_joiner = True
            continue
        if skip_joiner and is_emoji_codepoint(code):
            skip_joiner = False
            continue
        skip_joiner = False
        total += 2 if is_wide_for_x(code) else 1
    return total


def is_wide_for_x(code: int) -> bool:
    if is_emoji_codepoint(code):
        return True
    if 0x1100 <= code <= 0x11FF:
        return True
    if 0x2E80 <= code <= 0xA4CF:
        return True
    if 0xAC00 <= code <= 0xD7AF:
        return True
    if 0xF900 <= code <= 0xFAFF:
        return True
    if 0xFE10 <= code <= 0xFE6F:
        return True
    if 0xFF00 <= code <= 0xFFEF:
        return True
    return code > 0x10FF


def is_emoji_codepoint(code: int) -> bool:
    return (
        0x1F000 <= code <= 0x1FAFF
        or 0x2600 <= code <= 0x27BF
        or 0x2300 <= code <= 0x23FF
    )


def normalize_display_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (int, float)):
        return str(int(value)) if float(value).is_integer() else str(value)
    if isinstance(value, list):
        parts = []
        for item in value:
            if isinstance(item, dict):
                parts.append(str(item.get("text") or item.get("name") or item.get("value") or ""))
            else:
                parts.append(str(item))
        return ";".join(part for part in parts if part)
    if isinstance(value, dict):
        for key in ("text", "name", "value"):
            if key in value:
                return normalize_display_value(value[key])
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def is_ascii(value: str) -> bool:
    try:
        value.encode("ascii")
        return True
    except UnicodeEncodeError:
        return False


def parse_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y", "on"}
    return bool(value)


def single_line(text: str) -> str:
    return " ".join((text or "").split())


def mask_token(value: str) -> str:
    if len(value) <= 8:
        return "***"
    return value[:4] + "..." + value[-4:]
