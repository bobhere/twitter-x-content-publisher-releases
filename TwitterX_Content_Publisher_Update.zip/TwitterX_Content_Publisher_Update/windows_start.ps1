$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

function Write-Step($Text) {
    Write-Host ""
    Write-Host "==> $Text" -ForegroundColor Cyan
}

function Write-Ok($Text) {
    Write-Host "[OK] $Text" -ForegroundColor Green
}

function Write-Warn($Text) {
    Write-Host "[WARN] $Text" -ForegroundColor Yellow
}

function Write-Fail($Text) {
    Write-Host "[ERROR] $Text" -ForegroundColor Red
}

function Refresh-Path {
    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machinePath;$userPath"
}

function Command-Exists($Name) {
    return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue)
}

function Read-FeishuConfig {
    $configPath = Join-Path $ScriptDir "feishu_config.json"
    $examplePath = Join-Path $ScriptDir "feishu_config.example.json"

    if (-not (Test-Path $configPath) -and (Test-Path $examplePath)) {
        Copy-Item $examplePath $configPath
        Write-Warn "feishu_config.json was not found. Created it from the example file."
    }

    if (-not (Test-Path $configPath)) {
        Write-Warn "feishu_config.json was not found."
        return $null
    }

    try {
        return Get-Content $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        Write-Warn "feishu_config.json is not valid JSON: $($_.Exception.Message)"
        return $null
    }
}

function Get-PythonCommand {
    if (Command-Exists "py") {
        & py -3 --version *> $null
        if ($LASTEXITCODE -eq 0) {
            return @{ Cmd = "py"; Args = @("-3") }
        }
    }

    if (Command-Exists "python") {
        & python --version *> $null
        if ($LASTEXITCODE -eq 0) {
            return @{ Cmd = "python"; Args = @() }
        }
    }

    return $null
}

function Try-Winget-Install($PackageId, $DisplayName) {
    if (-not (Command-Exists "winget")) {
        Write-Warn "winget was not found. Cannot auto install $DisplayName."
        return $false
    }

    Write-Warn "The installer may take several minutes. If it does not move, close this window and install $DisplayName manually."
    & winget install --id $PackageId -e --source winget --accept-package-agreements --accept-source-agreements --disable-interactivity
    if ($LASTEXITCODE -ne 0) {
        Write-Warn "$DisplayName auto install failed."
        return $false
    }

    Refresh-Path
    return $true
}

function Ensure-Python {
    $python = Get-PythonCommand
    if ($null -ne $python) {
        Write-Ok "Python is available."
        return $python
    }

    Write-Warn "Python was not found. Source mode needs Python 3.10 or newer."
    $answer = Read-Host "Type Y to install Python with winget, or press Enter to open the Python download page"
    if ($answer -match "^[Yy]") {
        $installed = Try-Winget-Install "Python.Python.3.12" "Python 3.12"
        if ($installed) {
            $python = Get-PythonCommand
            if ($null -ne $python) {
                Write-Ok "Python was installed."
                return $python
            }
        }
    }

    Start-Process "https://www.python.org/downloads/windows/"
    Write-Fail "Please install Python, then run run_windows.bat again."
    throw "Python missing"
}

function Check-LarkCli-Optional($Config) {
    if ($null -eq $Config) {
        return
    }

    $authMode = ""
    if ($Config.PSObject.Properties.Name -contains "auth_mode") {
        $authMode = [string]$Config.auth_mode
    }

    if ($authMode.ToLower() -notin @("lark_cli", "cli")) {
        return
    }

    Write-Step "lark_cli mode detected"
    if (-not (Command-Exists "lark-cli")) {
        Write-Warn "lark-cli is not installed on this PC."
        Write-Warn "The app will still open and can use local cache. Feishu live sync needs lark-cli or api mode."
        Write-Warn "Do not block startup by installing Node/lark-cli here. Install them later only if needed."
        return
    }

    Write-Ok "lark-cli is available."
    Write-Warn "Startup will not run lark-cli checks. Feishu sync errors will be shown inside the app."
}

function Check-Browser-Optional($Config) {
    if ($null -eq $Config) {
        return
    }

    $preference = "chrome"
    if ($Config.PSObject.Properties.Name -contains "browser_preference") {
        $preference = ([string]$Config.browser_preference).ToLower()
    }
    if ($preference -in @("edge", "microsoft edge", "msedge")) {
        $edgePaths = @(
            "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
            "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
            "$env:LocalAppData\Microsoft\Edge\Application\msedge.exe"
        )
        foreach ($path in $edgePaths) {
            if ($path -and (Test-Path $path)) {
                Write-Ok "Microsoft Edge is installed."
                return
            }
        }
        Write-Warn "Microsoft Edge was not detected. The app will fall back to the default browser."
        return
    }

    if ($preference -notin @("chrome", "google chrome")) {
        return
    }

    $chromePaths = @(
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:LocalAppData\Google\Chrome\Application\chrome.exe"
    )
    foreach ($path in $chromePaths) {
        if ($path -and (Test-Path $path)) {
            Write-Ok "Chrome is installed."
            return
        }
    }

    Write-Warn "Chrome was not detected. The app will fall back to the default browser."
}

function Start-App {
    $localExe = Join-Path $ScriptDir "TwitterX_Content_Publisher.exe"
    $distExe = Join-Path $ScriptDir "dist\TwitterX_Content_Publisher\TwitterX_Content_Publisher.exe"
    $sourceFile = Join-Path $ScriptDir "twitter_assistant.py"

    if (Test-Path $localExe) {
        Write-Step "Starting Windows app"
        Start-Process -FilePath $localExe -WorkingDirectory $ScriptDir
        return
    }

    if (Test-Path $distExe) {
        Write-Step "Starting packaged app"
        Start-Process -FilePath $distExe -WorkingDirectory (Split-Path -Parent $distExe)
        return
    }

    if (-not (Test-Path $sourceFile)) {
        Write-Fail "TwitterX_Content_Publisher.exe and twitter_assistant.py were not found."
        throw "app files missing"
    }

    $python = Ensure-Python
    Write-Step "Starting source version with Python"
    $pythonCmd = $python["Cmd"]
    $pythonArgs = $python["Args"] + @($sourceFile)
    & $pythonCmd @pythonArgs
}

try {
    Write-Step "Twitter / X Content Publisher Windows launcher"
    $config = Read-FeishuConfig
    Check-LarkCli-Optional $config
    Check-Browser-Optional $config
    Start-App
} catch {
    Write-Fail $_.Exception.Message
    exit 1
}
