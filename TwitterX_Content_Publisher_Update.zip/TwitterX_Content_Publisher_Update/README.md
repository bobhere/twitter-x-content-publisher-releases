# Twitter / X 内容发布台

这个工具用于“飞书内容库 + 排期提醒 + 文案预览 + 准备发布”。它不调用 X API，也不会模拟点击 X 网站的发布按钮。

## 它会做什么

- 从飞书多维表格读取文案内容库。
- 飞书未配置时，使用本地 `posts.csv` 示例数据。
- 按计划发布时间提醒你。
- 展示全文预览、普通字数、X 加权长度、链接数量和规则提示。
- 自动复制文案到剪贴板。
- 可配置优先用 Chrome 或 Edge 打开 X 发帖页；找不到指定浏览器时回退系统默认浏览器。
- 发布后可以把内容标记为 `已发布`，并回写飞书或本地示例。

## 它不会做什么

- 不会自动点击 X 的“发布”按钮。
- 不会自动登录、绕验证码、绕风控。
- 不会批量关注、点赞、私信或回复。

这能省掉大部分机械操作，同时比浏览器脚本全自动发布更稳。

## 飞书接入

第一阶段建议把飞书多维表格作为唯一云端数据库。人工在飞书里录入、审核、作废文案；软件通过 API 读取和回写状态。

1. 按 [feishu_base_schema.md](./feishu_base_schema.md) 创建一张 `文案库` 表。
2. 创建飞书/飞书国际版 Lark 自建应用。
3. 给应用开通多维表格读取和写入记录权限。
4. 把该应用添加为目标多维表格协作者，并给编辑权限。
5. 复制 `feishu_config.example.json` 为 `feishu_config.json`。
6. 填入 `app_id`、`app_secret`、`base_token`、`table_id`，并把 `enabled` 改为 `true`。

如果本机已经配置好 `lark-cli`，也可以不填写 `app_secret`，改用 CLI 模式：

```json
{
  "enabled": true,
  "auth_mode": "lark_cli",
  "lark_cli_identity": "bot"
}
```

CLI 模式会调用本机 `lark-cli` 读写飞书多维表格，适合当前电脑已经完成飞书 CLI 授权的场景。

自动同步默认每 60 分钟一次，可在 `feishu_config.json` 里调整：

```json
{
  "auto_sync_minutes": 60,
  "browser_preference": "chrome"
}
```

Windows 内部分发时也可以把 `browser_preference` 设置为 `edge`，让发帖页和飞书表优先用 Microsoft Edge 打开。

软件每分钟检查一次本地已加载的排期提醒；点击“同步 / 刷新”会立即读取飞书。

如果使用 Lark 国际版，把 `api_base` 改为：

```text
https://open.larksuite.com/open-apis
```

`feishu_config.json` 里包含密钥，已经被 `.gitignore` 忽略，不要发给无关人员。
如果使用 `auth_mode: "lark_cli"` 且 `app_secret` 留空，配置文件本身不包含飞书密钥，但目标电脑也必须安装并配置好 `lark-cli`。

## macOS 运行

需要 Python 3.10 或更新版本。

双击 `run_mac.command`，或者在终端运行：

```bash
python3 twitter_assistant.py
```

如果系统提示没有执行权限，运行：

```bash
chmod +x run_mac.command
```

## Windows 运行

优先双击：

```bat
run_windows.bat
```

它会调用 `windows_start.ps1` 做启动前检查：

- 如果有打包好的 `TwitterX_Content_Publisher.exe`，直接打开 exe。
- 如果只有源码，会检查 Python；缺失时会询问是否用 `winget` 安装，避免启动器直接卡在下载工具。
- 如果配置是 `lark_cli` 模式，只提示 lark-cli 状态，不再自动安装 Node.js / npm / lark-cli。缺工具时软件会先使用本地缓存。
- 如果没有配置指定的 Chrome / Edge，会回退系统默认浏览器。

Windows 同事不需要安装飞书客户端。当前 `lark_cli` 模式下，只有“实时同步飞书”和“回写飞书状态”需要本机安装并配置 `lark-cli`；没有 `lark-cli` 时仍可读取随包带的本地缓存并继续发布，状态更新会先写在本地缓存里。

也可以在 PowerShell 或 CMD 里运行：

```bat
python twitter_assistant.py
```

Windows 交付细节见 [WINDOWS_QUICK_START.md](./WINDOWS_QUICK_START.md)。

## 网页运营看板

如果需要让团队成员用浏览器查看整体运营状态，可以启动网页看板：

macOS：

```bash
./run_dashboard.command
```

Windows：

```bat
run_dashboard_windows.bat
```

网页看板会复用同一套飞书 / 本地缓存数据，展示内容库存、今日队列、7 天排期、分类健康、待审核积压、长度风险和全文预览。它是只读运营台，发布动作仍建议在桌面端完成。

详细说明见 [WEB_DASHBOARD.md](./WEB_DASHBOARD.md)。

## 自动更新

软件启动后会读取公开更新源，发现新版本时会弹窗提示一键更新。更新会保留本机的 `feishu_config.json`、`posts.csv`、`posts_cache.csv` 和本地批量内容文件。

也可以手动点击：

```text
帮助 -> 检查更新
```

详细说明见 [UPDATE_GUIDE.md](./UPDATE_GUIDE.md)。

## 本地示例字段

| 字段 | 说明 |
| --- | --- |
| `id` | 内容编号，自定义即可 |
| `record_id` | 飞书记录 ID，本地示例可留空 |
| `scheduled_at` | 发布时间，例如 `2026-06-04 10:30` |
| `text` | 要发布的文案 |
| `status` | `可发布`、`已安排`、`ready`、`pending` 到点会提醒；`已发布`、`作废` 不提醒 |
| `category` | 分类 |
| `tags` | 标签，多个用英文分号分隔 |
| `language` | 语言 |
| `priority` | 优先级 |
| `source` | AI / 人工 / 导入 |
| `assignee` | 负责人 |
| `posted_at` | 标记已发布时自动填写 |
| `notes` | 备注 |

示例表格里的时间故意写成了 `2099-01-01`，避免你第一次打开程序就马上弹提醒。正式使用时，把它改成当天或未来的实际时间。

批量导入文案时，优先使用 Excel / CSV，一行一条内容。具体要求见 [content_import_guide.md](./content_import_guide.md)。

## 推荐流程

1. 创作者或 AI 把内容写进飞书多维表格。
2. 审核人员把合格内容改成 `可发布` 或 `已安排`。
3. 发布人员打开本地软件，同步飞书内容库。
4. 到点后点击“准备发布”。
5. 检查文案，手动点击 X 的发布按钮。
6. 回到程序点击“标记已发布”。
