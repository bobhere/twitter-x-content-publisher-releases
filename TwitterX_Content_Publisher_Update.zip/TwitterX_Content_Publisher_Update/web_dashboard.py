#!/usr/bin/env python3
import argparse
import json
import mimetypes
import socket
import subprocess
import threading
import time
import urllib.parse
import webbrowser
from collections import Counter, defaultdict
from datetime import date, datetime, time as dt_time, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from content_store import (
    DONE_STATUSES,
    REJECTED_STATUSES,
    FeishuPostStore,
    Post,
    StoreResult,
    single_line,
)


BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "web_dashboard"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8765
CACHE_SECONDS = 60
DAILY_TARGET = 10
CATEGORY_MIN_READY = 3


STATE_LABELS = {
    "draft": "草稿",
    "review": "待审核",
    "ready": "可发布",
    "scheduled": "已安排",
    "published": "已发布",
    "rejected": "作废",
    "unknown": "其他",
}


class DashboardService:
    def __init__(self, base_dir: Path):
        self.store = FeishuPostStore(base_dir)
        self._cache: dict[str, Any] | None = None
        self._cache_at = 0.0
        self._lock = threading.RLock()

    def dashboard(self, force: bool = False) -> dict[str, Any]:
        with self._lock:
            now = time.time()
            if self._cache and not force and now - self._cache_at < CACHE_SECONDS:
                return self._cache

            result = self.store.load()
            payload = build_dashboard_payload(result, self.store.config.safe_summary, self.store.config.base_url)
            self._cache = payload
            self._cache_at = now
            return payload


def build_dashboard_payload(result: StoreResult, config_summary: str, base_url: str) -> dict[str, Any]:
    now = datetime.now()
    today_start = datetime.combine(now.date(), dt_time.min)
    tomorrow_start = today_start + timedelta(days=1)
    week_end = today_start + timedelta(days=7)

    posts = sorted(
        result.posts,
        key=lambda post: (
            post.scheduled_at is None,
            post.scheduled_at or datetime.max,
            post.post_id,
        ),
    )

    serialized_posts = [serialize_post(post, now, today_start, tomorrow_start, week_end) for post in posts]
    status_counts = Counter(item["state"] for item in serialized_posts)
    category_stats = build_category_stats(serialized_posts)
    assignee_stats = build_assignee_stats(serialized_posts)
    timeline = build_timeline(serialized_posts, today_start)
    risks = build_risks(serialized_posts, category_stats)

    today_queue = [item for item in serialized_posts if item["is_today"] and item["state"] not in {"published", "rejected"}]
    week_queue = [item for item in serialized_posts if item["is_week"] and item["state"] not in {"published", "rejected"}]
    review_queue = [item for item in serialized_posts if item["state"] in {"review", "draft"}]
    ready_pool = [
        item
        for item in serialized_posts
        if item["state"] in {"ready", "scheduled"}
        and item["state"] not in {"published", "rejected"}
        and not item["is_today"]
    ]
    risk_posts = [
        item
        for item in serialized_posts
        if item["is_due"] or item["metrics"]["weighted_length"] > 280 or (item["state"] in {"ready", "scheduled"} and not item["scheduled_at"])
    ]

    publishable = status_counts["ready"] + status_counts["scheduled"]
    active_total = len([item for item in serialized_posts if item["state"] not in {"published", "rejected"}])
    week_scheduled = len(week_queue)
    due_count = len([item for item in serialized_posts if item["is_due"]])
    long_count = len([item for item in serialized_posts if item["metrics"]["weighted_length"] > 280])
    no_schedule_publishable = len(
        [item for item in serialized_posts if item["state"] in {"ready", "scheduled"} and not item["scheduled_at"]]
    )

    return {
        "generated_at": now.strftime("%Y-%m-%d %H:%M:%S"),
        "source_label": result.source_label,
        "warning": result.warning,
        "config_summary": config_summary,
        "base_url": base_url,
        "targets": {
            "daily": DAILY_TARGET,
            "week": DAILY_TARGET * 7,
            "category_min_ready": CATEGORY_MIN_READY,
        },
        "summary": {
            "total": len(serialized_posts),
            "active_total": active_total,
            "publishable": publishable,
            "review": status_counts["review"],
            "draft": status_counts["draft"],
            "scheduled": status_counts["scheduled"],
            "ready": status_counts["ready"],
            "published": status_counts["published"],
            "rejected": status_counts["rejected"],
            "today_queue": len(today_queue),
            "week_queue": week_scheduled,
            "due": due_count,
            "long": long_count,
            "no_schedule_publishable": no_schedule_publishable,
            "publishable_days": round(publishable / DAILY_TARGET, 1) if DAILY_TARGET else 0,
            "week_gap": max(0, DAILY_TARGET * 7 - week_scheduled),
        },
        "status_counts": [
            {"state": key, "label": STATE_LABELS.get(key, key), "count": status_counts[key]}
            for key in ["draft", "review", "ready", "scheduled", "published", "rejected", "unknown"]
            if status_counts[key]
        ],
        "category_stats": category_stats,
        "assignee_stats": assignee_stats,
        "timeline": timeline,
        "risks": risks,
        "queues": {
            "today": today_queue[:20],
            "week": week_queue[:40],
            "review": review_queue[:40],
            "ready": ready_pool[:40],
            "risk": risk_posts[:40],
        },
        "posts": serialized_posts[:800],
    }


def serialize_post(post: Post, now: datetime, today_start: datetime, tomorrow_start: datetime, week_end: datetime) -> dict[str, Any]:
    metrics = post.metrics
    scheduled_at = post.scheduled_at
    state = classify_state(post)
    text = post.text or ""
    category = post.category or "未分类"
    tags = split_tags(post.tags)
    is_due = bool(scheduled_at and scheduled_at <= now and state not in {"published", "rejected"})
    is_today = bool(scheduled_at and today_start <= scheduled_at < tomorrow_start)
    is_week = bool(scheduled_at and today_start <= scheduled_at < week_end)
    platform = infer_platform(post)
    summary = single_line(text)
    if len(summary) > 90:
        summary = summary[:90] + "..."

    return {
        "id": post.post_id,
        "record_id": post.record_id,
        "scheduled_at": scheduled_at.strftime("%Y-%m-%d %H:%M") if scheduled_at else "",
        "scheduled_date": scheduled_at.strftime("%Y-%m-%d") if scheduled_at else "",
        "scheduled_time": scheduled_at.strftime("%H:%M") if scheduled_at else "",
        "posted_at": post.data.get("posted_at", ""),
        "status": post.status or "草稿",
        "state": state,
        "state_label": STATE_LABELS.get(state, "其他"),
        "category": category,
        "tags": tags,
        "tags_text": post.tags,
        "language": post.data.get("language", ""),
        "priority": post.priority or "未设置",
        "source": post.source or "未设置",
        "assignee": post.assignee or "未分配",
        "platform": platform,
        "notes": post.data.get("notes", ""),
        "text": text,
        "summary": summary,
        "is_due": is_due,
        "is_today": is_today,
        "is_week": is_week,
        "metrics": {
            "visible_length": metrics.visible_length,
            "weighted_length": metrics.weighted_length,
            "url_count": metrics.url_count,
            "line_count": metrics.line_count,
            "label": metrics.label,
        },
    }


def classify_state(post: Post) -> str:
    status = (post.status or "").strip()
    normalized = post.normalized_status
    if normalized in DONE_STATUSES:
        return "published"
    if normalized in REJECTED_STATUSES:
        return "rejected"
    if status in {"待审核", "审核中"} or normalized in {"review", "needs_review"}:
        return "review"
    if status in {"草稿"} or normalized in {"draft"}:
        return "draft"
    if status in {"已安排"} or normalized in {"scheduled"}:
        return "scheduled"
    if status in {"可发布", "待发布"} or normalized in {"ready", "pending"}:
        return "ready"
    if not status:
        return "draft"
    return "unknown"


def split_tags(tags: str) -> list[str]:
    return [part.strip() for part in (tags or "").replace("，", ";").split(";") if part.strip()]


def infer_platform(post: Post) -> str:
    blob = " ".join([post.tags, post.category, post.data.get("notes", "")]).lower()
    if "朋友圈" in blob or "wechat" in blob or "moments" in blob:
        return "朋友圈"
    if "twitter" in blob or "x/" in blob or " x " in f" {blob} ":
        return "X"
    return "通用"


def build_category_stats(posts: list[dict[str, Any]]) -> list[dict[str, Any]]:
    buckets: dict[str, dict[str, Any]] = {}
    for item in posts:
        category = item["category"] or "未分类"
        bucket = buckets.setdefault(
            category,
            {
                "category": category,
                "total": 0,
                "draft": 0,
                "review": 0,
                "ready": 0,
                "scheduled": 0,
                "published": 0,
                "rejected": 0,
                "unknown": 0,
                "publishable": 0,
                "active": 0,
                "health": "ok",
            },
        )
        state = item["state"]
        bucket["total"] += 1
        bucket[state] = bucket.get(state, 0) + 1
        if state in {"ready", "scheduled"}:
            bucket["publishable"] += 1
        if state not in {"published", "rejected"}:
            bucket["active"] += 1

    stats = list(buckets.values())
    for item in stats:
        if item["publishable"] < CATEGORY_MIN_READY and item["active"] > 0:
            item["health"] = "low"
        elif item["review"] >= DAILY_TARGET * 2:
            item["health"] = "review"
        else:
            item["health"] = "ok"

    return sorted(stats, key=lambda row: (-row["active"], row["category"]))


def build_assignee_stats(posts: list[dict[str, Any]]) -> list[dict[str, Any]]:
    buckets: dict[str, Counter] = defaultdict(Counter)
    for item in posts:
        buckets[item["assignee"]][item["state"]] += 1
        buckets[item["assignee"]]["total"] += 1
    rows = []
    for assignee, counter in buckets.items():
        rows.append(
            {
                "assignee": assignee,
                "total": counter["total"],
                "review": counter["review"],
                "ready": counter["ready"],
                "scheduled": counter["scheduled"],
                "published": counter["published"],
            }
        )
    return sorted(rows, key=lambda row: (-row["total"], row["assignee"]))[:12]


def build_timeline(posts: list[dict[str, Any]], today_start: datetime) -> list[dict[str, Any]]:
    rows = []
    for offset in range(7):
        current = today_start.date() + timedelta(days=offset)
        date_text = current.strftime("%Y-%m-%d")
        day_posts = [
            item
            for item in posts
            if item["scheduled_date"] == date_text and item["state"] not in {"published", "rejected"}
        ]
        rows.append(
            {
                "date": date_text,
                "label": "今天" if offset == 0 else current.strftime("%m-%d"),
                "count": len(day_posts),
                "gap": max(0, DAILY_TARGET - len(day_posts)),
                "items": day_posts[:8],
            }
        )
    return rows


def build_risks(posts: list[dict[str, Any]], category_stats: list[dict[str, Any]]) -> list[dict[str, Any]]:
    risks = []
    due_count = len([item for item in posts if item["is_due"]])
    if due_count:
        risks.append({"level": "high", "title": "到点未处理", "count": due_count, "detail": "有内容已经到计划发布时间。"})

    publishable = len([item for item in posts if item["state"] in {"ready", "scheduled"}])
    if publishable < DAILY_TARGET * 3:
        risks.append({"level": "high", "title": "可发布库存偏低", "count": publishable, "detail": "按每天 10 条估算，当前可直接发布内容不足 3 天。"})

    review = len([item for item in posts if item["state"] == "review"])
    if review >= DAILY_TARGET * 3:
        risks.append({"level": "medium", "title": "待审核积压", "count": review, "detail": "内容池充足，但需要尽快审核转成可发布。"})

    no_schedule = len([item for item in posts if item["state"] in {"ready", "scheduled"} and not item["scheduled_at"]])
    if no_schedule:
        risks.append({"level": "medium", "title": "可发布但未排期", "count": no_schedule, "detail": "这些内容可以进入发布日历。"})

    long_posts = len([item for item in posts if item["metrics"]["weighted_length"] > 280])
    if long_posts:
        risks.append({"level": "low", "title": "长文需要拆分", "count": long_posts, "detail": "超过普通 X 帖限制，发布前要拆 thread 或改写。"})

    low_categories = [item for item in category_stats if item["health"] == "low"]
    if low_categories:
        risks.append({"level": "medium", "title": "分类可发布不足", "count": len(low_categories), "detail": "部分分类缺少已审核内容，容易导致选题结构失衡。"})

    if not risks:
        risks.append({"level": "ok", "title": "运营状态稳定", "count": 0, "detail": "当前没有明显阻塞项。"})
    return risks


def make_handler(service: DashboardService):
    class DashboardHandler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            parsed = urllib.parse.urlparse(self.path)
            path = urllib.parse.unquote(parsed.path)
            query = urllib.parse.parse_qs(parsed.query)

            if path == "/api/health":
                self.send_json({"ok": True, "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})
                return
            if path == "/api/dashboard":
                force = query.get("force", ["0"])[0] in {"1", "true", "yes"}
                try:
                    self.send_json(service.dashboard(force=force))
                except Exception as exc:
                    self.send_json({"ok": False, "error": str(exc)}, status=500)
                return

            self.send_static(path)

        def send_json(self, data: dict[str, Any], status: int = 200) -> None:
            body = json.dumps(data, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def send_static(self, path: str) -> None:
            if path in {"", "/"}:
                target = STATIC_DIR / "index.html"
            else:
                relative = path.lstrip("/")
                target = STATIC_DIR / relative
                if not target.suffix:
                    target = STATIC_DIR / "index.html"

            try:
                resolved = target.resolve()
                if STATIC_DIR.resolve() not in resolved.parents and resolved != STATIC_DIR.resolve():
                    self.send_error(403)
                    return
            except OSError:
                self.send_error(404)
                return

            if not resolved.exists() or not resolved.is_file():
                self.send_error(404)
                return

            body = resolved.read_bytes()
            content_type = mimetypes.guess_type(str(resolved))[0] or "application/octet-stream"
            if resolved.suffix in {".html", ".css", ".js"}:
                content_type += "; charset=utf-8"
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, format: str, *args: Any) -> None:
            return

    return DashboardHandler


def find_open_port(host: str, preferred_port: int) -> int:
    for port in range(preferred_port, preferred_port + 30):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                sock.bind((host, port))
            except OSError:
                continue
            return port
    raise RuntimeError(f"Cannot find an open port starting at {preferred_port}.")


def open_dashboard_url(url: str, browser: str) -> None:
    preference = (browser or "default").strip().lower()
    if preference in {"edge", "microsoft edge", "msedge"} and open_edge(url):
        return
    if preference in {"chrome", "google chrome"} and open_chrome(url):
        return
    webbrowser.open(url, new=2)


def open_edge(url: str) -> bool:
    candidates = [
        "/Applications/Microsoft Edge.app",
        str(Path.home() / "Applications/Microsoft Edge.app"),
        str(Path.home() / "AppData/Local/Microsoft/Edge/Application/msedge.exe"),
        "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
        "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
    ]
    return open_by_candidates(url, candidates, "Microsoft Edge")


def open_chrome(url: str) -> bool:
    candidates = [
        "/Applications/Google Chrome.app",
        str(Path.home() / "Applications/Google Chrome.app"),
        str(Path.home() / "AppData/Local/Google/Chrome/Application/chrome.exe"),
        "C:/Program Files/Google/Chrome/Application/chrome.exe",
        "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
    ]
    return open_by_candidates(url, candidates, "Google Chrome")


def open_by_candidates(url: str, candidates: list[str], mac_app_name: str) -> bool:
    try:
        if candidates[0].endswith(".app"):
            for candidate in candidates[:2]:
                if Path(candidate).exists():
                    subprocess.Popen(["open", "-a", mac_app_name, url])
                    return True
        for candidate in candidates[2:]:
            if Path(candidate).exists():
                subprocess.Popen([candidate, url])
                return True
    except OSError:
        return False
    return False


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the Twitter/X content operations dashboard.")
    parser.add_argument("--host", default=DEFAULT_HOST)
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--open", action="store_true", help="Open the dashboard in the default browser.")
    parser.add_argument("--browser", default="default", choices=["default", "chrome", "edge"], help="Browser to use with --open.")
    args = parser.parse_args()

    if not STATIC_DIR.exists():
        raise SystemExit(f"Missing dashboard static directory: {STATIC_DIR}")

    port = find_open_port(args.host, args.port)
    service = DashboardService(BASE_DIR)
    server = ThreadingHTTPServer((args.host, port), make_handler(service))
    url = f"http://{args.host}:{port}/"
    print(f"Dashboard running at {url}")
    print("Press Ctrl+C to stop.")
    if args.open:
        threading.Timer(0.6, lambda: open_dashboard_url(url, args.browser)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nDashboard stopped.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
