#!/bin/zsh
set -e
cd "$(dirname "$0")"
python3 web_dashboard.py --open
