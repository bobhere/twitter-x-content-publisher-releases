#!/bin/zsh
set -e
cd "$(dirname "$0")"

python3 -m pip install --upgrade pip pyinstaller

if [ ! -f feishu_config.json ]; then
  echo "[WARN] feishu_config.json does not exist. The packaged app will start in local sample mode."
fi

python3 -m PyInstaller \
  --noconfirm \
  --clean \
  --windowed \
  --name "TwitterX_Content_Publisher" \
  --add-data "content_store.py:." \
  --add-data "feishu_base_schema.md:." \
  --add-data "content_import_guide.md:." \
  --add-data "feishu_config.example.json:." \
  --add-data "version.json:." \
  --add-data "update_config.json:." \
  --add-data "apply_update.py:." \
  --add-data "posts.csv:." \
  twitter_assistant.py

if [ -f feishu_config.json ]; then
  cp feishu_config.json "dist/TwitterX_Content_Publisher/feishu_config.json"
fi

cp feishu_base_schema.md "dist/TwitterX_Content_Publisher/feishu_base_schema.md"
cp content_import_guide.md "dist/TwitterX_Content_Publisher/content_import_guide.md"
cp README.md "dist/TwitterX_Content_Publisher/README.md"
cp DISTRIBUTION.md "dist/TwitterX_Content_Publisher/DISTRIBUTION.md"
cp WINDOWS_QUICK_START.md "dist/TwitterX_Content_Publisher/WINDOWS_QUICK_START.md"
cp WEB_DASHBOARD.md "dist/TwitterX_Content_Publisher/WEB_DASHBOARD.md"
cp UPDATE_GUIDE.md "dist/TwitterX_Content_Publisher/UPDATE_GUIDE.md"
cp version.json "dist/TwitterX_Content_Publisher/version.json"
cp update_config.json "dist/TwitterX_Content_Publisher/update_config.json"
cp app_update.py "dist/TwitterX_Content_Publisher/app_update.py"
cp apply_update.py "dist/TwitterX_Content_Publisher/apply_update.py"
cp web_dashboard.py "dist/TwitterX_Content_Publisher/web_dashboard.py"
cp run_dashboard.command "dist/TwitterX_Content_Publisher/run_dashboard.command"
cp -R web_dashboard "dist/TwitterX_Content_Publisher/web_dashboard"

echo ""
echo "Build complete:"
echo "dist/TwitterX_Content_Publisher/TwitterX_Content_Publisher.app"
