@echo off
setlocal
cd /d "%~dp0"

python -m pip install --upgrade pip pyinstaller

if not exist feishu_config.json (
  echo [WARN] feishu_config.json does not exist. The packaged app will start in local sample mode.
)

python -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --windowed ^
  --name "TwitterX_Content_Publisher" ^
  --add-data "content_store.py;." ^
  --add-data "feishu_base_schema.md;." ^
  --add-data "content_import_guide.md;." ^
  --add-data "feishu_config.example.json;." ^
  --add-data "version.json;." ^
  --add-data "update_config.json;." ^
  --add-data "apply_update.py;." ^
  --add-data "posts.csv;." ^
  twitter_assistant.py

if exist feishu_config.json (
  copy /Y feishu_config.json "dist\TwitterX_Content_Publisher\feishu_config.json" >nul
)

copy /Y feishu_base_schema.md "dist\TwitterX_Content_Publisher\feishu_base_schema.md" >nul
copy /Y content_import_guide.md "dist\TwitterX_Content_Publisher\content_import_guide.md" >nul
copy /Y README.md "dist\TwitterX_Content_Publisher\README.md" >nul
copy /Y DISTRIBUTION.md "dist\TwitterX_Content_Publisher\DISTRIBUTION.md" >nul
copy /Y WINDOWS_QUICK_START.md "dist\TwitterX_Content_Publisher\WINDOWS_QUICK_START.md" >nul
copy /Y WEB_DASHBOARD.md "dist\TwitterX_Content_Publisher\WEB_DASHBOARD.md" >nul
copy /Y UPDATE_GUIDE.md "dist\TwitterX_Content_Publisher\UPDATE_GUIDE.md" >nul
copy /Y version.json "dist\TwitterX_Content_Publisher\version.json" >nul
copy /Y update_config.json "dist\TwitterX_Content_Publisher\update_config.json" >nul
copy /Y app_update.py "dist\TwitterX_Content_Publisher\app_update.py" >nul
copy /Y apply_update.py "dist\TwitterX_Content_Publisher\apply_update.py" >nul
copy /Y web_dashboard.py "dist\TwitterX_Content_Publisher\web_dashboard.py" >nul
copy /Y run_windows.bat "dist\TwitterX_Content_Publisher\run_windows.bat" >nul
copy /Y windows_start.ps1 "dist\TwitterX_Content_Publisher\windows_start.ps1" >nul
copy /Y run_dashboard_windows.bat "dist\TwitterX_Content_Publisher\run_dashboard_windows.bat" >nul
xcopy /E /I /Y web_dashboard "dist\TwitterX_Content_Publisher\web_dashboard" >nul
copy /Y posts.csv "dist\TwitterX_Content_Publisher\posts.csv" >nul
if exist posts_cache.csv copy /Y posts_cache.csv "dist\TwitterX_Content_Publisher\posts_cache.csv" >nul
if exist generated_content_batch_20260605.csv copy /Y generated_content_batch_20260605.csv "dist\TwitterX_Content_Publisher\generated_content_batch_20260605.csv" >nul

echo.
echo Build complete:
echo dist\TwitterX_Content_Publisher\TwitterX_Content_Publisher.exe
echo Double-click dist\TwitterX_Content_Publisher\run_windows.bat to start with dependency checks.
echo.
pause
