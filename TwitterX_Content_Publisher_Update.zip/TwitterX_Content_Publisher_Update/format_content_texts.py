import argparse
import csv
from pathlib import Path

from content_text_formatter import format_post_text


TEXT_COLUMNS = ("text", "文案正文", "content", "正文")


def main() -> int:
    parser = argparse.ArgumentParser(description="Format generated X/朋友圈 copy with better punctuation and paragraph breaks.")
    parser.add_argument("files", nargs="+", help="CSV files to inspect or update.")
    parser.add_argument("--write", action="store_true", help="Write formatted text back to the CSV files.")
    parser.add_argument("--column", help="Text column name. Defaults to auto detection.")
    parser.add_argument("--sample", type=int, default=8, help="Number of changed samples to print per file.")
    args = parser.parse_args()

    total_changed = 0
    for file_name in args.files:
        changed = format_csv(Path(file_name), column=args.column, write=args.write, sample=args.sample)
        total_changed += changed

    action = "updated" if args.write else "would update"
    print(f"\nDone: {action} {total_changed} row(s).")
    return 0


def format_csv(path: Path, column: str | None, write: bool, sample: int) -> int:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames or []
        rows = list(reader)
    text_column = column or detect_text_column(fieldnames)
    if not text_column:
        raise SystemExit(f"{path}: no text column found. Tried: {', '.join(TEXT_COLUMNS)}")

    changed_samples = []
    changed_count = 0
    for row in rows:
        old_text = row.get(text_column, "")
        new_text = format_post_text(old_text)
        if new_text != old_text:
            changed_count += 1
            if len(changed_samples) < sample:
                changed_samples.append((row.get("id") or row.get("编号") or "-", old_text, new_text))
            row[text_column] = new_text

    print(f"\n{path}: {changed_count}/{len(rows)} row(s) changed")
    for post_id, old_text, new_text in changed_samples:
        print(f"\n[{post_id}] BEFORE\n{old_text}")
        print(f"[{post_id}] AFTER\n{new_text}")

    if write:
        with path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, lineterminator="\n")
            writer.writeheader()
            writer.writerows(rows)

    return changed_count


def detect_text_column(fieldnames: list[str]) -> str | None:
    for column in TEXT_COLUMNS:
        if column in fieldnames:
            return column
    return None


if __name__ == "__main__":
    raise SystemExit(main())
