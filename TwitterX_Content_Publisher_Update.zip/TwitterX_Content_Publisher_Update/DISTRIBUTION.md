# 内部分发说明

你们两个人内部使用时，可以把飞书 API 配置放在本地发布包里。这样同事拿到软件后，打开就会连接同一张飞书多维表格。

## 推荐方式

```text
飞书多维表格：云端唯一数据源
feishu_config.json：随软件放在本地
Mac / Windows 客户端：读取同一份配置，操作同一张表
```

当前项目支持两种连接方式：

```text
api 模式：feishu_config.json 内含 app_id / app_secret，目标电脑无需 lark-cli。
lark_cli 模式：feishu_config.json 不含 app_secret，但目标电脑必须安装并配置 lark-cli。
```

当前这台 Mac 已配置为 `lark_cli` 模式。

## 给 Windows 同事

需要在 Windows 电脑上构建一次 Windows 版。PyInstaller 不能在 macOS 上直接生成 Windows `.exe`。

步骤：

1. 把整个项目文件夹复制到 Windows 电脑。
2. 确认文件夹里有已经填好的 `feishu_config.json`。
3. 双击 `build_windows.bat`。
4. 构建完成后，把这个文件夹发给同事：

```text
dist\TwitterX_Content_Publisher
```

同事打开：

```text
run_windows.bat
```

`run_windows.bat` 会自动检查依赖。源码版缺 Python 时会询问是否安装；Node.js、lark-cli、Chrome 不再自动安装，避免 Windows 网络安装卡住导致软件打不开。

如果当前是 `lark_cli` 模式，启动器不会阻塞启动；没有 lark-cli 时，软件先读本地缓存。想让同事真正“拿到就双击、不配置并且能实时同步飞书”，建议切换到 `api` 模式，把 `app_id/app_secret/base_token/table_id` 写进 `feishu_config.json` 后再分发。

## 给 Mac 同事

在 Mac 上双击：

```text
build_mac.command
```

构建完成后分发：

```text
dist/TwitterX_Content_Publisher
```

## 安全提醒

如果 `feishu_config.json` 里有 `app_secret`，它等于这套软件访问飞书内容库的钥匙。只适合发给可信内部成员，不要发到公开仓库、公开群或外包人员手里。

如果使用 `lark_cli` 模式，配置文件不含 `app_secret`，但每台电脑都需要单独配置 `lark-cli`。

如果后续成员超过 5 人，建议升级为 Cloudflare Worker 中间层，把飞书密钥集中放在云端环境变量里。
