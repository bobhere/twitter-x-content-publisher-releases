import hashlib
import json
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any


VERSION_FILE = "version.json"
UPDATE_CONFIG_FILE = "update_config.json"
DEFAULT_MANIFEST_URL = "https://raw.githubusercontent.com/bobhere/twitter-x-content-publisher-releases/main/update_manifest.json"


class UpdateError(Exception):
    pass


@dataclass
class UpdateInfo:
    version: str
    notes: str
    url: str
    sha256: str = ""
    size: int = 0


def load_current_version(base_dir: Path) -> str:
    path = base_dir / VERSION_FILE
    if not path.exists():
        return "0.0.0"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return "0.0.0"
    return str(data.get("version") or "0.0.0").strip() or "0.0.0"


def load_update_config(base_dir: Path) -> dict[str, Any]:
    path = base_dir / UPDATE_CONFIG_FILE
    config = {
        "enabled": True,
        "check_on_start": True,
        "manifest_url": DEFAULT_MANIFEST_URL,
    }
    if not path.exists():
        return config
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return config
    config.update(data or {})
    if not config.get("manifest_url"):
        config["manifest_url"] = DEFAULT_MANIFEST_URL
    return config


def should_check_on_start(base_dir: Path) -> bool:
    config = load_update_config(base_dir)
    return bool(config.get("enabled", True) and config.get("check_on_start", True))


def check_for_update(base_dir: Path, timeout: int = 8) -> UpdateInfo | None:
    config = load_update_config(base_dir)
    if not config.get("enabled", True):
        return None

    current = load_current_version(base_dir)
    manifest = fetch_json(str(config.get("manifest_url") or DEFAULT_MANIFEST_URL), timeout=timeout)
    remote_version = str(manifest.get("version") or "").strip()
    if not remote_version:
        raise UpdateError("更新清单缺少 version。")
    if compare_versions(remote_version, current) <= 0:
        return None

    package = pick_package(manifest)
    url = str(package.get("url") or package.get("download_url") or manifest.get("download_url") or "").strip()
    if not url:
        raise UpdateError("更新清单缺少下载地址。")
    return UpdateInfo(
        version=remote_version,
        notes=str(manifest.get("notes") or "").strip(),
        url=url,
        sha256=str(package.get("sha256") or manifest.get("sha256") or "").strip(),
        size=int(package.get("size") or manifest.get("size") or 0),
    )


def fetch_json(url: str, timeout: int = 8) -> dict[str, Any]:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            raw = response.read().decode("utf-8")
    except urllib.error.URLError as exc:
        raise UpdateError(f"无法连接更新服务器：{exc.reason}") from exc
    except OSError as exc:
        raise UpdateError(f"无法读取更新清单：{exc}") from exc
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise UpdateError("更新清单不是有效 JSON。") from exc


def pick_package(manifest: dict[str, Any]) -> dict[str, Any]:
    packages = manifest.get("packages") or {}
    system = platform.system().lower()
    if system == "windows":
        keys = ["windows", "source"]
    elif system == "darwin":
        keys = ["macos", "mac", "source"]
    else:
        keys = ["linux", "source"]
    for key in keys:
        package = packages.get(key)
        if isinstance(package, dict):
            return package
    if manifest.get("download_url") or manifest.get("url"):
        return manifest
    raise UpdateError("更新清单里没有适合当前系统的安装包。")


def download_update(info: UpdateInfo, base_dir: Path, timeout: int = 60) -> Path:
    updates_dir = base_dir / ".updates"
    updates_dir.mkdir(parents=True, exist_ok=True)
    target = updates_dir / f"update-{info.version}.zip"
    temp_target = Path(tempfile.mkstemp(prefix="download-", suffix=".zip", dir=str(updates_dir))[1])

    digest = hashlib.sha256()
    try:
        with urllib.request.urlopen(info.url, timeout=timeout) as response, temp_target.open("wb") as f:
            while True:
                chunk = response.read(1024 * 512)
                if not chunk:
                    break
                digest.update(chunk)
                f.write(chunk)
    except urllib.error.URLError as exc:
        temp_target.unlink(missing_ok=True)
        raise UpdateError(f"更新包下载失败：{exc.reason}") from exc
    except OSError as exc:
        temp_target.unlink(missing_ok=True)
        raise UpdateError(f"更新包保存失败：{exc}") from exc

    actual_sha = digest.hexdigest()
    if info.sha256 and actual_sha.lower() != info.sha256.lower():
        temp_target.unlink(missing_ok=True)
        raise UpdateError("更新包校验失败，文件可能下载不完整。")

    if target.exists():
        target.unlink()
    shutil.move(str(temp_target), str(target))
    return target


def launch_apply_update(base_dir: Path, zip_path: Path, restart_command: list[str]) -> None:
    script = base_dir / "apply_update.py"
    if not script.exists():
        raise UpdateError("缺少 apply_update.py，无法执行自动更新。")
    python_cmd = python_launcher()
    if not python_cmd:
        raise UpdateError("未找到可用于执行更新脚本的 Python。")
    command = python_cmd + [
        str(script),
        "--zip",
        str(zip_path),
        "--target",
        str(base_dir),
        "--restart",
        json.dumps(restart_command, ensure_ascii=False),
    ]
    subprocess.Popen(command, cwd=str(base_dir), close_fds=True)


def python_launcher() -> list[str]:
    if not getattr(sys, "frozen", False):
        return [sys.executable]
    if platform.system() == "Windows":
        py = shutil.which("py")
        if py:
            return [py, "-3"]
    python = shutil.which("python3") or shutil.which("python")
    return [python] if python else []


def restart_command_for_app(main_file: Path) -> list[str]:
    if getattr(sys, "frozen", False):
        return [sys.executable]
    return [sys.executable, str(main_file)]


def compare_versions(left: str, right: str) -> int:
    left_parts = version_parts(left)
    right_parts = version_parts(right)
    max_len = max(len(left_parts), len(right_parts))
    left_parts += [0] * (max_len - len(left_parts))
    right_parts += [0] * (max_len - len(right_parts))
    if left_parts > right_parts:
        return 1
    if left_parts < right_parts:
        return -1
    return 0


def version_parts(version: str) -> list[int]:
    parts = [int(item) for item in re.findall(r"\d+", version or "")]
    return parts or [0]
