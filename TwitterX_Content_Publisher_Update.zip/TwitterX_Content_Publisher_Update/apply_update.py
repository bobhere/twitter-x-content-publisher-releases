#!/usr/bin/env python3
import argparse
import fnmatch
import json
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path


PROTECTED_NAMES = {
    "feishu_config.json",
    "posts.csv",
    "posts_cache.csv",
}

PROTECTED_PATTERNS = [
    "generated_content_batch_*.csv",
    "*.sqlite",
    "*.db",
]


def is_protected(relative_path: Path) -> bool:
    name = relative_path.name
    if name in PROTECTED_NAMES:
        return True
    return any(fnmatch.fnmatch(name, pattern) for pattern in PROTECTED_PATTERNS)


def find_payload_root(extract_dir: Path) -> Path:
    entries = [item for item in extract_dir.iterdir() if item.name != "__MACOSX"]
    if len(entries) == 1 and entries[0].is_dir():
        return entries[0]
    return extract_dir


def apply_update(zip_path: Path, target_dir: Path) -> None:
    work_dir = target_dir / ".updates" / "extract"
    if work_dir.exists():
        shutil.rmtree(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(work_dir)

    payload_root = find_payload_root(work_dir)
    for source in payload_root.rglob("*"):
        if source.is_dir():
            continue
        relative = source.relative_to(payload_root)
        if is_protected(relative):
            continue
        destination = target_dir / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def main() -> int:
    parser = argparse.ArgumentParser(description="Apply a downloaded Twitter/X Content Publisher update.")
    parser.add_argument("--zip", required=True)
    parser.add_argument("--target", required=True)
    parser.add_argument("--restart", default="")
    args = parser.parse_args()

    zip_path = Path(args.zip).resolve()
    target_dir = Path(args.target).resolve()
    log_path = target_dir / ".updates" / "update.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        time.sleep(1.5)
        apply_update(zip_path, target_dir)
        log_path.write_text(f"Update applied at {time.strftime('%Y-%m-%d %H:%M:%S')}\n", encoding="utf-8")
        if args.restart:
            restart_command = json.loads(args.restart)
            if isinstance(restart_command, list) and restart_command:
                subprocess.Popen(restart_command, cwd=str(target_dir), close_fds=True)
    except Exception as exc:
        log_path.write_text(f"Update failed: {exc}\n", encoding="utf-8")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
