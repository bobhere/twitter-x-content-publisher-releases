# 自动更新说明

这个项目采用最简单的自动更新方式：

```text
私有源码仓库：保存代码
公开更新仓库：只保存无密钥更新包和 update_manifest.json
客户端：启动时读取公开 update_manifest.json，发现新版本后提示一键更新
```

公开更新仓库：

```text
https://github.com/bobhere/twitter-x-content-publisher-releases
```

更新清单地址：

```text
https://raw.githubusercontent.com/bobhere/twitter-x-content-publisher-releases/main/update_manifest.json
```

## 更新时会保留什么

一键更新不会覆盖这些本地文件：

```text
feishu_config.json
posts.csv
posts_cache.csv
generated_content_batch_*.csv
*.sqlite
*.db
```

所以同事本机的飞书配置、本地缓存和本地内容不会因为更新丢失。

## 使用方式

桌面端启动后会自动检查更新。也可以在菜单里点击：

```text
帮助 -> 检查更新
```

发现新版本后，软件会提示是否更新。点击确认后会下载更新包、关闭当前软件、覆盖代码文件，然后重新打开。

## 发布新版本的流程

1. 修改代码并提交到私有源码仓库。
2. 修改 `version.json`，例如从 `1.0.0` 改为 `1.0.1`。
3. 生成无密钥更新包。
4. 把更新包和新的 `update_manifest.json` 上传到公开更新仓库。

公开更新包不要包含：

```text
feishu_config.json
posts_cache.csv
generated_content_batch_*.csv
```

这些文件只能留在内部安装包或各自电脑本地。
