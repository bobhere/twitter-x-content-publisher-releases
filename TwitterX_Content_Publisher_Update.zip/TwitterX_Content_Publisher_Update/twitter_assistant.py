import os
import platform
import shutil
import subprocess
import sys
import threading
import time
import webbrowser
from datetime import datetime
from pathlib import Path
from tkinter import BOTH, END, LEFT, RIGHT, TOP, Button, Frame, Label, Menu, Tk, Toplevel, messagebox
from tkinter.scrolledtext import ScrolledText
from tkinter.ttk import Scrollbar, Style, Treeview
from urllib.parse import quote

import app_update
from content_store import (
    DONE_STATUSES,
    FEISHU_CONFIG_FILE,
    FeishuPostStore,
    Post,
    REJECTED_STATUSES,
    StoreError,
    single_line,
)


APP_TITLE = "Twitter / X 内容发布台"
REMINDER_CHECK_SECONDS = 60


class TwitterAssistantApp:
    def __init__(self, root: Tk, store: FeishuPostStore):
        self.root = root
        self.store = store
        self.posts: list[Post] = []
        self.snoozed_until: dict[str, float] = {}
        self.running = True
        self.current_post: Post | None = None
        self.source_label_text = "加载中"
        self.warning_text = ""
        self.last_sync_at = 0.0
        self.update_check_running = False
        self.update_installing = False
        self.table_columns = ("time", "status", "post_id", "category", "x_len", "summary")

        self.root.title(APP_TITLE)
        self.root.geometry("1120x720")
        self.root.minsize(900, 600)

        self.build_menu()
        self.build_layout()
        self.reload_posts(show_warning=False)
        self.start_checker()
        self.schedule_startup_update_check()

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def build_menu(self) -> None:
        menu_bar = Menu(self.root)
        file_menu = Menu(menu_bar, tearoff=0)
        file_menu.add_command(label="同步 / 刷新", command=lambda: self.reload_posts(show_warning=True))
        file_menu.add_command(label="测试飞书连接", command=self.test_feishu_connection)
        file_menu.add_separator()
        file_menu.add_command(label="打开飞书配置", command=self.open_config_file)
        file_menu.add_command(label="打开飞书文案库", command=self.open_feishu_base)
        file_menu.add_command(label="打开导入规范", command=lambda: open_path(self.store.base_dir / "content_import_guide.md"))
        file_menu.add_command(label="打开表结构说明", command=lambda: open_path(self.store.base_dir / "feishu_base_schema.md"))
        file_menu.add_command(label="打开程序目录", command=lambda: open_path(self.store.base_dir))
        file_menu.add_separator()
        file_menu.add_command(label="退出", command=self.on_close)
        menu_bar.add_cascade(label="文件", menu=file_menu)

        help_menu = Menu(menu_bar, tearoff=0)
        help_menu.add_command(label="检查更新", command=lambda: self.check_for_updates(manual=True))
        help_menu.add_separator()
        help_menu.add_command(label="使用说明", command=self.show_help)
        menu_bar.add_cascade(label="帮助", menu=help_menu)
        self.root.config(menu=menu_bar)

    def build_layout(self) -> None:
        header = Frame(self.root, padx=12, pady=10)
        header.pack(side=TOP, fill="x")

        title = Label(header, text=APP_TITLE, font=("Arial", 18, "bold"))
        title.pack(side=LEFT)

        self.source_label = Label(header, text="", anchor="e")
        self.source_label.pack(side=RIGHT)

        stats = Frame(self.root, padx=12)
        stats.pack(side=TOP, fill="x", pady=(0, 8))

        self.inventory_label = Label(stats, text="", anchor="w", justify=LEFT)
        self.inventory_label.pack(side=LEFT)

        self.warning_label = Label(stats, text="", anchor="e", justify=RIGHT, fg="#8a4b00")
        self.warning_label.pack(side=RIGHT)

        body = Frame(self.root, padx=12, pady=6)
        body.pack(fill=BOTH, expand=True)

        left_panel = Frame(body)
        left_panel.pack(side=LEFT, fill=BOTH, expand=False)
        left_panel.configure(width=650)
        left_panel.pack_propagate(False)

        Label(left_panel, text="内容列表", anchor="w", font=("Arial", 12, "bold")).pack(fill="x", pady=(0, 6))

        table_frame = Frame(left_panel)
        table_frame.pack(fill=BOTH, expand=True)

        style = Style()
        style.configure("Content.Treeview", rowheight=28)
        style.configure("Content.Treeview.Heading", font=("Arial", 11, "bold"))

        self.post_table = Treeview(
            table_frame,
            columns=self.table_columns,
            show="headings",
            selectmode="browse",
            style="Content.Treeview",
        )
        self.post_table.heading("time", text="计划时间", anchor="w")
        self.post_table.heading("status", text="状态", anchor="w")
        self.post_table.heading("post_id", text="ID", anchor="w")
        self.post_table.heading("category", text="分类", anchor="w")
        self.post_table.heading("x_len", text="X", anchor="center")
        self.post_table.heading("summary", text="摘要", anchor="w")

        self.post_table.column("time", width=132, minwidth=120, stretch=False, anchor="w")
        self.post_table.column("status", width=82, minwidth=72, stretch=False, anchor="w")
        self.post_table.column("post_id", width=72, minwidth=64, stretch=False, anchor="w")
        self.post_table.column("category", width=72, minwidth=64, stretch=False, anchor="w")
        self.post_table.column("x_len", width=48, minwidth=44, stretch=False, anchor="center")
        self.post_table.column("summary", width=220, minwidth=160, stretch=True, anchor="w")

        self.post_table.tag_configure("due", background="#fff5cc")
        self.post_table.tag_configure("long", background="#fff0e0")
        self.post_table.tag_configure("posted", foreground="#6b7280")
        self.post_table.tag_configure("rejected", foreground="#8a8f98", background="#f3f4f6")

        scrollbar = Scrollbar(table_frame, orient="vertical", command=self.post_table.yview)
        self.post_table.configure(yscrollcommand=scrollbar.set)
        self.post_table.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.pack(side=RIGHT, fill="y")
        self.post_table.bind("<<TreeviewSelect>>", self.on_select)

        right_panel = Frame(body, padx=12)
        right_panel.pack(side=LEFT, fill=BOTH, expand=True)

        self.detail_label = Label(right_panel, text="选择一条内容查看详情", anchor="w", justify=LEFT)
        self.detail_label.pack(fill="x")

        metrics_row = Frame(right_panel)
        metrics_row.pack(fill="x", pady=(8, 0))

        self.length_label = Label(metrics_row, text="", anchor="w", justify=LEFT)
        self.length_label.pack(side=LEFT)

        self.rule_label = Label(metrics_row, text="", anchor="e", justify=RIGHT)
        self.rule_label.pack(side=RIGHT)

        self.text_preview = ScrolledText(right_panel, height=18, wrap="word")
        self.text_preview.pack(fill=BOTH, expand=True, pady=(8, 8))
        self.text_preview.configure(state="disabled")

        self.meta_label = Label(right_panel, text="", anchor="w", justify=LEFT)
        self.meta_label.pack(fill="x")

        button_row_1 = Frame(right_panel, pady=8)
        button_row_1.pack(fill="x")

        Button(button_row_1, text="准备发布", command=self.prepare_selected, width=14).pack(side=LEFT, padx=(0, 8))
        Button(button_row_1, text="复制文案", command=self.copy_selected_text, width=12).pack(side=LEFT, padx=(0, 8))
        Button(button_row_1, text="打开 X 发帖页", command=self.open_compose_selected, width=14).pack(side=LEFT, padx=(0, 8))
        Button(button_row_1, text="同步 / 刷新", command=lambda: self.reload_posts(show_warning=True), width=12).pack(side=LEFT, padx=(0, 8))
        Button(button_row_1, text="测试飞书", command=self.test_feishu_connection, width=12).pack(side=LEFT, padx=(0, 8))

        button_row_2 = Frame(right_panel, pady=4)
        button_row_2.pack(fill="x")

        Button(button_row_2, text="标记已发布", command=self.mark_posted, width=14).pack(side=LEFT, padx=(0, 8))
        Button(button_row_2, text="标记已安排", command=self.mark_scheduled, width=12).pack(side=LEFT, padx=(0, 8))
        Button(button_row_2, text="改为可发布", command=self.mark_ready, width=12).pack(side=LEFT, padx=(0, 8))
        Button(button_row_2, text="标记作废", command=self.mark_rejected, width=12).pack(side=LEFT, padx=(0, 8))
        Button(button_row_2, text="打开飞书表", command=self.open_feishu_base, width=12).pack(side=LEFT, padx=(0, 8))
        Button(button_row_2, text="打开配置", command=self.open_config_file, width=10).pack(side=LEFT, padx=(0, 8))

        footer = Frame(self.root, padx=12, pady=8)
        footer.pack(side=TOP, fill="x")
        self.footer_label = Label(footer, text="", anchor="w", justify=LEFT)
        self.footer_label.pack(fill="x")

    def reload_posts(self, show_warning: bool = False) -> None:
        selected_id = self.current_post.post_id if self.current_post else None
        result = self.store.load()
        self.last_sync_at = time.time()
        self.apply_store_result(result, selected_id=selected_id)
        if show_warning and result.warning:
            messagebox.showwarning("同步提示", result.warning)

    def apply_store_result(self, result, selected_id: str | None = None) -> None:
        self.source_label_text = result.source_label
        self.warning_text = result.warning
        self.posts = sorted(
            result.posts,
            key=lambda post: (
                post.scheduled_at is None,
                post.scheduled_at or datetime.max,
                post.post_id,
            ),
        )

        for item in self.post_table.get_children():
            self.post_table.delete(item)
        selected_index = 0
        for index, post in enumerate(self.posts):
            if selected_id and post.post_id == selected_id:
                selected_index = index
            self.post_table.insert(
                "",
                END,
                iid=str(index),
                values=self.table_values(post),
                tags=self.table_tags(post),
            )

        if self.posts:
            selected_iid = str(selected_index)
            self.post_table.selection_set(selected_iid)
            self.post_table.focus(selected_iid)
            self.post_table.see(selected_iid)
            self.show_post(self.posts[selected_index])
        else:
            self.current_post = None
            self.show_empty()

        self.update_status()

    def table_values(self, post: Post) -> tuple[str, str, str, str, str, str]:
        schedule = post.raw_scheduled_at or "未设置时间"
        status = post.status or "草稿"
        if post.is_due:
            status = f"{status} · 到点"
        category = post.category or "未分类"
        weighted = post.metrics.weighted_length
        text = single_line(post.text)
        if len(text) > 32:
            text = text[:32] + "..."
        return schedule, status, post.post_id, category, str(weighted), text

    def table_tags(self, post: Post) -> tuple[str, ...]:
        tags = []
        if post.is_due:
            tags.append("due")
        if post.metrics.weighted_length > 280:
            tags.append("long")
        if post.normalized_status in DONE_STATUSES:
            tags.append("posted")
        if post.normalized_status in REJECTED_STATUSES:
            tags.append("rejected")
        return tuple(tags)

    def on_select(self, _event=None) -> None:
        selection = self.post_table.selection()
        if not selection:
            return
        index = int(selection[0])
        if 0 <= index < len(self.posts):
            self.show_post(self.posts[index])

    def show_post(self, post: Post) -> None:
        self.current_post = post
        schedule = post.raw_scheduled_at or "未设置"
        status = post.status or "草稿"
        category = post.category or "未分类"
        self.detail_label.configure(
            text=f"ID: {post.post_id}    发布时间: {schedule}    状态: {status}    分类: {category}"
        )

        metrics = post.metrics
        self.length_label.configure(
            text=f"普通字数: {metrics.visible_length}    X 加权长度: {metrics.weighted_length}    行数: {metrics.line_count}    链接: {metrics.url_count}"
        )
        color = "#107c41" if metrics.weighted_length <= 280 else "#9a6700" if metrics.weighted_length <= 25000 else "#b42318"
        self.rule_label.configure(text=metrics.label, fg=color)

        self.text_preview.configure(state="normal")
        self.text_preview.delete("1.0", END)
        self.text_preview.insert("1.0", post.text)
        self.text_preview.configure(state="disabled")

        meta = [
            f"标签: {post.tags or '无'}",
            f"语言: {post.data.get('language', '') or '未设置'}",
            f"优先级: {post.priority or '未设置'}",
            f"来源: {post.source or '未设置'}",
            f"负责人: {post.assignee or '未设置'}",
        ]
        notes = post.data.get("notes", "").strip()
        if notes:
            meta.append(f"备注: {notes}")
        self.meta_label.configure(text="    ".join(meta))

    def show_empty(self) -> None:
        self.detail_label.configure(text="内容库里还没有可显示内容")
        self.length_label.configure(text="")
        self.rule_label.configure(text="")
        self.text_preview.configure(state="normal")
        self.text_preview.delete("1.0", END)
        self.text_preview.configure(state="disabled")
        self.meta_label.configure(text="")

    def prepare_selected(self) -> None:
        post = self.require_selected_post()
        if not post:
            return
        self.copy_text(post)
        browser_label, prefilled = self.open_compose(post, prefill=True)
        self.root.bell()
        details = [
            "文案已复制，X 发帖页已打开。",
            f"打开方式：{browser_label}。",
        ]
        if not prefilled:
            details.append("这条内容超过普通帖预填范围，进入页面后直接粘贴剪贴板内容。")
        details.append("请检查内容后手动点击发布。这个工具不会自动点击 X 的发布按钮。")
        messagebox.showinfo(
            "准备好了",
            "\n\n".join(details),
        )

    def copy_selected_text(self) -> None:
        post = self.require_selected_post()
        if post:
            self.copy_text(post)
            messagebox.showinfo("已复制", "文案已复制到剪贴板。")

    def open_compose_selected(self) -> None:
        post = self.require_selected_post()
        if post:
            browser_label, prefilled = self.open_compose(post, prefill=True)
            if not prefilled:
                self.copy_text(post)
                messagebox.showinfo(
                    "已打开",
                    f"已用 {browser_label} 打开 X 发帖页。\n\n这条内容超过普通帖预填范围，文案已复制到剪贴板。",
                )

    def mark_posted(self) -> None:
        post = self.require_selected_post()
        if not post:
            return
        self.update_post_status(
            post,
            {
                "status": "已发布",
                "posted_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            },
        )

    def mark_scheduled(self) -> None:
        post = self.require_selected_post()
        if post:
            self.update_post_status(post, {"status": "已安排"})

    def mark_ready(self) -> None:
        post = self.require_selected_post()
        if post:
            self.update_post_status(post, {"status": "可发布", "posted_at": ""})

    def mark_rejected(self) -> None:
        post = self.require_selected_post()
        if post:
            self.update_post_status(post, {"status": "作废"})

    def update_post_status(self, post: Post, values: dict[str, str]) -> None:
        try:
            self.store.update_post(post, values)
            self.reload_posts(show_warning=False)
        except StoreError as exc:
            messagebox.showerror("更新失败", str(exc))

    def copy_text(self, post: Post) -> None:
        self.root.clipboard_clear()
        self.root.clipboard_append(post.text)
        self.root.update()

    def open_compose(self, post: Post, prefill: bool = True) -> tuple[str, bool]:
        text = post.text.strip()
        if prefill and text and post.metrics.weighted_length <= 280:
            url = f"https://twitter.com/intent/tweet?text={quote(text)}"
            is_prefilled = True
        else:
            url = "https://x.com/compose/post"
            is_prefilled = False
        browser_label = open_url(url, self.store.config.browser_preference)
        return browser_label, is_prefilled

    def require_selected_post(self) -> Post | None:
        if self.current_post:
            return self.current_post
        messagebox.showwarning("未选择", "请先选择一条内容。")
        return None

    def test_feishu_connection(self) -> None:
        try:
            message = self.store.test_connection()
            messagebox.showinfo("飞书连接", message)
        except StoreError as exc:
            messagebox.showwarning("飞书连接", str(exc))

    def open_config_file(self) -> None:
        config_path = self.store.base_dir / FEISHU_CONFIG_FILE
        if not config_path.exists():
            example_path = self.store.base_dir / "feishu_config.example.json"
            if example_path.exists():
                shutil.copyfile(example_path, config_path)
        open_path(config_path)

    def open_feishu_base(self) -> None:
        url = build_feishu_base_url(self.store.config)
        if not url:
            messagebox.showwarning("飞书文案库", "飞书配置里还没有 base_token，暂时无法打开文案库。")
            return
        browser_label = open_url(url, self.store.config.browser_preference)
        self.footer_label.configure(text=f"已用 {browser_label} 打开飞书文案库。")

    def start_checker(self) -> None:
        thread = threading.Thread(target=self.check_loop, daemon=True)
        thread.start()

    def check_loop(self) -> None:
        while self.running:
            try:
                if self.should_auto_sync():
                    result = self.store.load()
                    sync_time = time.time()
                    self.root.after(0, lambda loaded_result=result, loaded_at=sync_time: self.check_due_posts(loaded_result, loaded_at))
                else:
                    self.root.after(0, self.check_due_posts_from_current)
            except RuntimeError:
                break
            time.sleep(REMINDER_CHECK_SECONDS)

    def should_auto_sync(self) -> bool:
        minutes = max(0, self.store.config.auto_sync_minutes)
        if minutes == 0:
            return False
        if self.last_sync_at <= 0:
            return True
        return time.time() - self.last_sync_at >= minutes * 60

    def check_due_posts(self, result, loaded_at: float | None = None) -> None:
        if not self.running:
            return
        if loaded_at is not None:
            self.last_sync_at = loaded_at
        due_post = self.find_due_post(result.posts)
        if due_post:
            self.snoozed_until[due_post.post_id] = time.time() + 300
            self.apply_store_result(result, selected_id=due_post.post_id)
            self.select_post_by_id(due_post.post_id)
            self.show_due_popup(due_post)
        else:
            selected_id = self.current_post.post_id if self.current_post else None
            self.apply_store_result(result, selected_id=selected_id)

    def check_due_posts_from_current(self) -> None:
        if not self.running:
            return
        due_post = self.find_due_post(self.posts)
        if due_post:
            self.snoozed_until[due_post.post_id] = time.time() + 300
            self.select_post_by_id(due_post.post_id)
            self.show_due_popup(due_post)

    def find_due_post(self, posts: list[Post]) -> Post | None:
        now_ts = time.time()
        due_posts = [
            post
            for post in posts
            if post.is_due and now_ts >= self.snoozed_until.get(post.post_id, 0)
        ]
        if not due_posts:
            return None
        return min(due_posts, key=lambda post: post.scheduled_at or datetime.max)

    def select_post_by_id(self, post_id: str) -> None:
        for index, post in enumerate(self.posts):
            if post.post_id == post_id:
                iid = str(index)
                self.post_table.selection_set(iid)
                self.post_table.focus(iid)
                self.post_table.see(iid)
                self.show_post(post)
                break

    def show_due_popup(self, post: Post) -> None:
        self.root.bell()
        popup = Toplevel(self.root)
        popup.title("到点发布")
        popup.geometry("560x280")
        popup.attributes("-topmost", True)
        popup.focus_force()

        Label(
            popup,
            text=f"到点了：{post.post_id}",
            font=("Arial", 16, "bold"),
            anchor="w",
        ).pack(fill="x", padx=16, pady=(16, 8))

        preview = single_line(post.text)
        if len(preview) > 110:
            preview = preview[:110] + "..."
        Label(popup, text=preview, wraplength=520, justify=LEFT, anchor="w").pack(fill="x", padx=16)

        metrics = post.metrics
        Label(
            popup,
            text=f"X 加权长度：{metrics.weighted_length}    {metrics.label}",
            anchor="w",
            fg="#555555",
        ).pack(fill="x", padx=16, pady=(8, 0))

        button_row = Frame(popup, pady=16)
        button_row.pack(fill="x", padx=16)

        Button(
            button_row,
            text="准备发布",
            command=lambda: [
                popup.destroy(),
                self.snooze_post(post.post_id, 3600),
                self.select_post_by_id(post.post_id),
                self.prepare_selected(),
            ],
            width=14,
        ).pack(side=LEFT, padx=(0, 8))
        Button(
            button_row,
            text="稍后提醒",
            command=lambda: [self.snooze_post(post.post_id, 600), popup.destroy()],
            width=12,
        ).pack(side=LEFT, padx=(0, 8))
        Button(
            button_row,
            text="标记已发布",
            command=lambda: [popup.destroy(), self.select_post_by_id(post.post_id), self.mark_posted()],
            width=12,
        ).pack(side=LEFT, padx=(0, 8))

    def snooze_post(self, post_id: str, seconds: int) -> None:
        self.snoozed_until[post_id] = time.time() + seconds

    def update_status(self) -> None:
        remindable = [post for post in self.posts if post.is_scheduled and post.scheduled_at is not None]
        scheduled = [post for post in self.posts if post.status in {"已安排", "scheduled"} and post.scheduled_at is not None]
        due = [post for post in remindable if post.scheduled_at <= datetime.now()]
        future = [post for post in remindable if post.scheduled_at > datetime.now()]
        ready = [post for post in self.posts if post.status in {"可发布", "ready"}]
        draft = [post for post in self.posts if post.status in {"草稿", "draft", "待审核"}]
        posted = [post for post in self.posts if post.normalized_status in DONE_STATUSES]
        rejected = [post for post in self.posts if post.normalized_status in REJECTED_STATUSES]

        if future:
            next_post = min(future, key=lambda post: post.scheduled_at or datetime.max)
            next_text = f"下一条：{next_post.raw_scheduled_at} / {next_post.post_id}"
        else:
            next_text = "下一条：无"

        self.source_label.configure(text=f"数据源：{self.source_label_text}")
        self.inventory_label.configure(
            text=f"总数 {len(self.posts)}    可发布 {len(ready)}    已安排 {len(scheduled)}    待提醒 {len(remindable)}    到点 {len(due)}    草稿/待审 {len(draft)}    已发布 {len(posted)}    作废 {len(rejected)}"
        )
        self.warning_label.configure(text=self.warning_text[:90] if self.warning_text else "")
        browser_text = browser_preference_label(self.store.config.browser_preference)
        sync_text = self.auto_sync_text()
        self.footer_label.configure(text=f"{next_text}    {sync_text}    浏览器：{browser_text}    配置：{self.store.config.safe_summary}")

    def auto_sync_text(self) -> str:
        minutes = max(0, self.store.config.auto_sync_minutes)
        if minutes == 0:
            interval = "自动同步：关闭"
        else:
            interval = f"自动同步：{minutes} 分钟"
        if self.last_sync_at <= 0:
            return interval
        last_sync = datetime.fromtimestamp(self.last_sync_at).strftime("%H:%M")
        return f"{interval} / 上次 {last_sync}"

    def show_help(self) -> None:
        messagebox.showinfo(
            "使用说明",
            "1. 第一阶段以飞书多维表格作为唯一云端内容库。\n"
            "2. 复制 feishu_config.example.json 为 feishu_config.json，填入应用和表格信息。\n"
            "3. 飞书未配置时，软件会使用本地 posts.csv 示例数据。\n"
            "4. 到点后点击“准备发布”，程序会复制文案并打开 X 发帖页。\n"
            "5. 浏览器可配置为 Chrome 或 Edge；找不到指定浏览器时回退系统默认浏览器。\n"
            "6. 软件每分钟检查本地排期，默认每 60 分钟自动同步一次飞书。\n"
            "7. 发布后点击“标记已发布”，状态会回写到飞书或本地缓存。\n"
            "8. 启动时会检查公开更新源；确认更新后会保留本地配置和缓存。\n"
            "9. 不合格文案建议标记“作废”，不要物理删除。",
        )

    def schedule_startup_update_check(self) -> None:
        if app_update.should_check_on_start(self.store.base_dir):
            self.root.after(2200, lambda: self.check_for_updates(manual=False))

    def check_for_updates(self, manual: bool = False) -> None:
        if self.update_check_running:
            if manual:
                messagebox.showinfo("检查更新", "正在检查更新，请稍等。")
            return
        self.update_check_running = True

        def worker() -> None:
            try:
                info = app_update.check_for_update(self.store.base_dir)
            except app_update.UpdateError as exc:
                self.root.after(0, lambda: self.finish_update_check_error(str(exc), manual))
                return
            except Exception as exc:
                self.root.after(0, lambda: self.finish_update_check_error(f"检查更新失败：{exc}", manual))
                return
            self.root.after(0, lambda: self.finish_update_check(info, manual))

        threading.Thread(target=worker, daemon=True).start()

    def finish_update_check_error(self, message: str, manual: bool) -> None:
        self.update_check_running = False
        if manual:
            messagebox.showwarning("检查更新", message)

    def finish_update_check(self, info: app_update.UpdateInfo | None, manual: bool) -> None:
        self.update_check_running = False
        if not info:
            if manual:
                current = app_update.load_current_version(self.store.base_dir)
                messagebox.showinfo("检查更新", f"当前已经是最新版本：{current}")
            return
        notes = f"\n\n更新说明：\n{info.notes}" if info.notes else ""
        confirmed = messagebox.askyesno(
            "发现新版本",
            f"发现新版本：{info.version}\n\n是否现在更新？软件会保留本机飞书配置和缓存。{notes}",
        )
        if confirmed:
            self.start_update_install(info)

    def start_update_install(self, info: app_update.UpdateInfo) -> None:
        if self.update_installing:
            return
        self.update_installing = True
        messagebox.showinfo("开始更新", "软件将下载更新包。下载完成后会自动关闭并重新打开。")

        def worker() -> None:
            try:
                zip_path = app_update.download_update(info, self.store.base_dir)
            except app_update.UpdateError as exc:
                self.root.after(0, lambda: self.finish_update_install_error(str(exc)))
                return
            except Exception as exc:
                self.root.after(0, lambda: self.finish_update_install_error(f"更新失败：{exc}"))
                return
            self.root.after(0, lambda: self.apply_update_and_exit(zip_path))

        threading.Thread(target=worker, daemon=True).start()

    def finish_update_install_error(self, message: str) -> None:
        self.update_installing = False
        messagebox.showerror("更新失败", message)

    def apply_update_and_exit(self, zip_path: Path) -> None:
        try:
            restart_command = app_update.restart_command_for_app(Path(__file__).resolve())
            app_update.launch_apply_update(self.store.base_dir, zip_path, restart_command)
        except app_update.UpdateError as exc:
            self.finish_update_install_error(str(exc))
            return
        self.running = False
        self.root.destroy()

    def on_close(self) -> None:
        self.running = False
        self.root.destroy()


def open_path(path: Path) -> None:
    path = path.resolve()
    system = platform.system()
    if system == "Darwin":
        subprocess.Popen(["open", str(path)])
    elif system == "Windows":
        try:
            import os

            os.startfile(str(path))  # type: ignore[attr-defined]
        except OSError:
            subprocess.Popen(["explorer", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])


def open_url(url: str, browser_preference: str = "chrome") -> str:
    preference = (browser_preference or "chrome").strip().lower()
    if preference in {"chrome", "google chrome"} and open_in_chrome(url):
        return "Chrome"
    if preference in {"edge", "microsoft edge", "msedge"} and open_in_edge(url):
        return "Microsoft Edge"
    webbrowser.open(url, new=2)
    return "系统默认浏览器"


def open_in_chrome(url: str) -> bool:
    system = platform.system()
    try:
        if system == "Darwin":
            chrome_apps = [
                Path("/Applications/Google Chrome.app"),
                Path.home() / "Applications/Google Chrome.app",
            ]
            if any(path.exists() for path in chrome_apps):
                subprocess.Popen(["open", "-a", "Google Chrome", url])
                return True
        elif system == "Windows":
            candidates = [
                shutil.which("chrome.exe"),
                shutil.which("chrome"),
                str(Path(os.environ.get("PROGRAMFILES", "")) / "Google/Chrome/Application/chrome.exe"),
                str(Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Google/Chrome/Application/chrome.exe"),
                str(Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/Application/chrome.exe"),
            ]
            for candidate in candidates:
                if candidate and Path(candidate).exists():
                    subprocess.Popen([candidate, url])
                    return True
        else:
            for name in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
                candidate = shutil.which(name)
                if candidate:
                    subprocess.Popen([candidate, url])
                    return True
    except OSError:
        return False
    return False


def open_in_edge(url: str) -> bool:
    system = platform.system()
    try:
        if system == "Darwin":
            edge_apps = [
                Path("/Applications/Microsoft Edge.app"),
                Path.home() / "Applications/Microsoft Edge.app",
            ]
            if any(path.exists() for path in edge_apps):
                subprocess.Popen(["open", "-a", "Microsoft Edge", url])
                return True
        elif system == "Windows":
            candidates = [
                shutil.which("msedge.exe"),
                shutil.which("msedge"),
                str(Path(os.environ.get("PROGRAMFILES", "")) / "Microsoft/Edge/Application/msedge.exe"),
                str(Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Microsoft/Edge/Application/msedge.exe"),
                str(Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft/Edge/Application/msedge.exe"),
            ]
            for candidate in candidates:
                if candidate and Path(candidate).exists():
                    subprocess.Popen([candidate, url])
                    return True
        else:
            candidate = shutil.which("microsoft-edge") or shutil.which("microsoft-edge-stable")
            if candidate:
                subprocess.Popen([candidate, url])
                return True
    except OSError:
        return False
    return False


def browser_preference_label(browser_preference: str) -> str:
    preference = (browser_preference or "chrome").strip().lower()
    if preference in {"chrome", "google chrome"}:
        return "Chrome 优先"
    if preference in {"edge", "microsoft edge", "msedge"}:
        return "Edge 优先"
    return "系统默认"


def build_feishu_base_url(config) -> str:
    if config.base_url:
        return config.base_url
    if not config.base_token:
        return ""
    host = "https://larksuite.com" if "larksuite.com" in config.api_base else "https://feishu.cn"
    url = f"{host}/base/{config.base_token}"
    if config.table_id:
        url += f"?table={config.table_id}"
    return url


def main() -> int:
    if getattr(sys, "frozen", False):
        base_dir = Path(sys.executable).resolve().parent
    else:
        base_dir = Path(__file__).resolve().parent
    store = FeishuPostStore(base_dir)
    root = Tk()
    TwitterAssistantApp(root, store)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
