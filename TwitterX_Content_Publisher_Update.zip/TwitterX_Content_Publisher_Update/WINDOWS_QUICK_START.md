# Windows 一键启动说明

给 Windows 同事时，推荐发打包后的文件夹：

```text
dist\TwitterX_Content_Publisher
```

同事打开方式：

```text
双击 run_windows.bat
```

如果文件夹里已经有：

```text
TwitterX_Content_Publisher.exe
```

启动器会直接打开 exe。

如果还没有 exe，但有源码文件：

```text
twitter_assistant.py
```

启动器会检查 Python，并用 Python 启动源码版。

## 启动器会自动检查什么

- Python：源码版运行需要；缺失时会询问是否用 `winget` 安装 Python 3.12。只有输入 `Y` 才会安装；直接回车会打开 Python 下载页。
- lark-cli：如果配置是 `lark_cli` 模式，启动器只做提示，不再自动安装 Node.js / npm / lark-cli，也不会阻塞启动。没有 lark-cli 时，软件会先使用随包带的本地缓存。
- Chrome：如果配置里是 `"browser_preference": "chrome"`，启动器会检查 Chrome。Chrome 不是必需项，缺失时软件会回退系统默认浏览器。

## 最省事的分发方式

如果你希望 Windows 同事完全不配置飞书 CLI，建议使用 `api` 模式：

```json
{
  "enabled": true,
  "auth_mode": "api",
  "app_id": "飞书应用 App ID",
  "app_secret": "飞书应用 App Secret",
  "base_token": "飞书多维表格 token",
  "table_id": "文案库 table_id"
}
```

这种模式下，Windows 同事双击启动器即可连接同一张飞书表，不需要单独安装和配置 `lark-cli`。

## 当前 lark_cli 模式的限制

`lark_cli` 模式不把 `app_secret` 放进项目文件，更安全，但每台电脑都需要本机配置 `lark-cli` 才能实时同步和回写飞书。这里说的是命令行工具，不是飞书客户端。启动器不会自动安装这些工具，因为 Windows 上的 `winget` / `npm` 网络安装可能长时间卡住。没有配置好时，软件仍会打开，并使用本地缓存查看内容；标记状态会先写入本地缓存，不会实时回写飞书。

如果启动器提示：

```text
lark-cli 尚未完成本机配置
```

说明这台 Windows 还没有可用的飞书 CLI 配置。此时有两个选择：

1. 切换到 `api` 模式再分发，适合两三个人内部可信使用。
2. 在 Windows 电脑上按飞书 CLI 流程完成配置，适合不想把 app_secret 放到本地配置里的场景。

## 文件不要拆散

分发时尽量保持这些文件在同一个文件夹里：

```text
TwitterX_Content_Publisher.exe
run_windows.bat
windows_start.ps1
feishu_config.json
README.md
DISTRIBUTION.md
content_import_guide.md
version.json
update_config.json
app_update.py
apply_update.py
```

## 自动更新

这版开始支持启动时检查更新。第一次仍然需要手动解压新版包；之后如果我们发布新版本，软件会弹窗提示一键更新。更新时会保留这台电脑自己的 `feishu_config.json` 和本地缓存。
