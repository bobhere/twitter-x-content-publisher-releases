import argparse
import csv
from pathlib import Path

from content_store import FeishuConfig, LarkCliClient, normalize_display_value


def main() -> int:
    parser = argparse.ArgumentParser(description="Sync formatted local copy text back to Feishu Base.")
    parser.add_argument("--cache", default="posts_cache.csv", help="Local cache CSV with record_id and text columns.")
    parser.add_argument("--write", action="store_true", help="Update Feishu. Without this flag only prints changes.")
    args = parser.parse_args()

    base_dir = Path(__file__).resolve().parent
    config = FeishuConfig(base_dir / "feishu_config.json").load()
    if not config.is_ready or not config.use_lark_cli:
        raise SystemExit("feishu_config.json is not ready for lark-cli sync.")

    local_rows = load_cache(base_dir / args.cache)
    client = LarkCliClient(config)
    remote_records = client.list_records()
    text_field = config.field_map.get("text", "文案正文")
    id_field = config.field_map.get("id", "编号")
    remote_by_record = {record.get("record_id", ""): record for record in remote_records}

    changes = []
    missing_record_ids = []
    missing_remote_records = []
    for row in local_rows:
        record_id = row.get("record_id", "").strip()
        if not record_id:
            missing_record_ids.append(row.get("id") or "-")
            continue
        remote = remote_by_record.get(record_id)
        if not remote:
            missing_remote_records.append(row.get("id") or record_id)
            continue
        old_text = normalize_display_value((remote.get("fields") or {}).get(text_field, ""))
        new_text = row.get("text", "")
        if old_text != new_text:
            post_id = row.get("id") or normalize_display_value((remote.get("fields") or {}).get(id_field, "")) or record_id
            changes.append((post_id, record_id, old_text, new_text))

    print(f"Local rows: {len(local_rows)}", flush=True)
    print(f"Remote records: {len(remote_records)}", flush=True)
    print(f"Missing local record_id rows: {len(missing_record_ids)}", flush=True)
    print(f"Missing remote record rows: {len(missing_remote_records)}", flush=True)
    print(f"Changed text rows: {len(changes)}", flush=True)
    if missing_record_ids:
        print(f"Rows without record_id: {', '.join(missing_record_ids[:20])}", flush=True)
    if missing_remote_records:
        print(f"Rows not found in Feishu: {', '.join(missing_remote_records[:20])}", flush=True)
    for post_id, _record_id, old_text, new_text in changes[:10]:
        print(f"\n[{post_id}]")
        print(f"- old: {single_line(old_text)[:120]}")
        print(f"+ new: {single_line(new_text)[:120]}")

    if args.write and (missing_record_ids or missing_remote_records):
        raise SystemExit("Cache and Feishu records do not fully match. Fix skipped rows before writing.")

    if not args.write:
        print("\nDry run only. Re-run with --write to update Feishu.")
        return 0

    for index, (post_id, record_id, _old_text, new_text) in enumerate(changes, start=1):
        client.update_record(record_id, {text_field: new_text})
        print(f"Updated {index}/{len(changes)}: {post_id}", flush=True)

    return 0


def load_cache(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def single_line(text: str) -> str:
    return " ".join((text or "").split())


if __name__ == "__main__":
    raise SystemExit(main())
