import re


QUESTION_HINTS = (
    "客户不解决",
    "这个问题拖延",
    "客户为什么",
    "客户自己为什么",
    "为什么",
    "凭什么",
    "你做了什么",
    "能不能",
    "有没有",
    "它能不能",
    "它有没有",
    "你能不能",
    "怎么做",
    "怎么交付",
    "怎么拒绝",
    "如何",
    "如果三个月后",
    "这是不是",
)

EXACT_REPLACEMENTS = (
    ("获客要可复制。交付要标准化。决策要快。", "获客要可复制，交付要标准化，决策要快。"),
    ("固定诊断。固定流程。固定交付物。以及", "固定诊断、固定流程、固定交付物，以及"),
    ("诊断。策略。执行。复盘。", "诊断、策略、执行、复盘。"),
    ("谁。什么问题。多长时间。得到什么结果。", "谁、什么问题、多长时间、得到什么结果。"),
    ("案例。流程。证明。交付物。", "案例、流程、证明、交付物。"),
    ("一个报价问题。一个筛选标准。一个交付边界。", "一个报价问题、一个筛选标准、一个交付边界。"),
    ("服务谁。不服务谁。卖什么。不卖什么。怎么交付。怎么拒绝。", "服务谁、不服务谁；卖什么、不卖什么；怎么交付、怎么拒绝。"),
    ("你理解他的痛苦。你有解决路径。你有交付能力。", "你理解他的痛苦；你有解决路径；你有交付能力。"),
    ("帮谁减少什么损失。创造什么增量。缩短多少时间。", "帮谁减少什么损失？创造什么增量？缩短多少时间？"),
    ("适合谁。不适合谁。", "适合谁、不适合谁。"),
    ("一个好定位，会让内容选题、案例表达、报价逻辑和交付边界变得统一。", "一个好定位会统一四件事：内容选题、案例表达、报价逻辑和交付边界。"),
    ("交付能力的终点，是客户离开你之后仍然能按你的系统继续运转。", "交付能力的终点是：客户离开你之后，仍然能按你的系统继续运转。"),
    ("真正有效的内容，会让客户在咨询前已经完成一半信任建设。", "真正有效的内容会提前完成一件事：让客户在咨询前，先建立一半信任。"),
)

REGEX_REPLACEMENTS = (
    (r"不是因为([^。！？；：]{1,36})。而是", r"不是因为\1，而是"),
    (r"不是([^。！？；：]{1,36})。而是", r"不是\1，而是"),
    (r"不是([^。！？；：]{1,36})。是被", r"不是\1，是被"),
    (r"不是([^。！？；：]{1,36})。是([^。！？；：]{1,36})。", r"不是\1，是\2。"),
    (r"客户愿意付高价。不是因为", "客户愿意付高价，不是因为"),
    (r"真正贵的是([^。！？；：]{1,36})。不是", r"真正贵的是\1，不是"),
    (r"关键是([^。！？；：]{1,36})。不是", r"关键是\1，不是"),
    (r"写不出来的地方。就是", "写不出来的地方，就是"),
    (r"这个说法不够准确。需要", "这个说法不够准确，需要"),
    (r"所有选择叠加起来。才会", "所有选择叠加起来，才会"),
    (r"越清楚越", "越清楚，越"),
    (r"不要([^。！？；：]{1,40})。而是", r"不要\1，而是"),
    (r"不要([^。！？；：]{1,40})。要", r"不要\1，要"),
    (r"可以没有([^。！？；：]{1,24})。但不能没有", r"可以没有\1，但不能没有"),
    (r"很多一人公司赚不到钱。不是", "很多一人公司赚不到钱，不是"),
    (r"如果([^。！？；：]{1,42})。通常", r"如果\1，通常"),
    (r"案例内容不要只写([^。！？；：]{1,42})。还要", r"案例内容不要只写\1，还要"),
    (r"(真正可持续的高客单服务)。应该", r"\1，应该"),
    (r"一人公司想做高客单。内容系统", "一人公司想做高客单，内容系统"),
    (r"每天不需要发很多。关键是", "每天不需要发很多，关键是"),
    (r"回答不清楚就先", "回答不清楚，就先"),
    (r"高客单通常卖的是([^。！？；：]{1,42})。因为", r"高客单通常卖的是\1，因为"),
    (r"把你的服务价格提高三倍。然后", "把你的服务价格提高三倍，然后"),
    (r"先([^。！？；：]{1,24})。再([^。！？；：]{1,24})。最后", r"先\1，再\2，最后"),
    (r"今天([^。！？；：]{1,20})。明天([^。！？；：]{1,20})。后天", r"今天\1，明天\2，后天"),
    (r"低客单([^。！？；：]{1,24})。中客单([^。！？；：]{1,24})。高客单([^。！？；：]{1,32})。", r"低客单\1；中客单\2；高客单\3。"),
    (r"(第[一二三四五六七八九十]+类是[^。！？；：]{1,18})。([^。！？；：]{1,48})。(?=第[一二三四五六七八九十]+类|每天|$)", r"\1，\2；"),
)

COLON_REPLACEMENTS = (
    (r"(三个问题|三个结果|三件事|四层|五类|一个小练习|复盘一下|今天先做一个粗糙想法)。", r"\1："),
    (r"(高客单简介应该像一个筛选器)。", r"\1："),
)


def format_post_text(text: str) -> str:
    text = normalize_text(text)
    if not text:
        return ""
    text = apply_punctuation_rules(text)
    text = paragraphize(text)
    return tidy_breaks(text)


def normalize_text(text: str) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    text = " ".join(text.replace("\r\n", "\n").replace("\r", "\n").split())
    text = re.sub(r"\s*([，。！？；：、])\s*", r"\1", text)
    text = re.sub(r"。{2,}", "。", text)
    return text


def apply_punctuation_rules(text: str) -> str:
    for old, new in EXACT_REPLACEMENTS:
        text = text.replace(old, new)
    for pattern, replacement in REGEX_REPLACEMENTS:
        text = re.sub(pattern, replacement, text)
    for pattern, replacement in COLON_REPLACEMENTS:
        text = re.sub(pattern, replacement, text)
    text = add_question_marks(text)
    text = cleanup_punctuation(text)
    return text


def add_question_marks(text: str) -> str:
    parts = split_units(text)
    updated = []
    for part in parts:
        body = part[:-1] if part[-1:] in "。！？；：" else part
        end = part[-1:] if part[-1:] in "。！？；：" else ""
        if end == "。" and should_be_question(body):
            updated.append(body + "？")
        else:
            updated.append(part)
    return "".join(updated)


def should_be_question(sentence: str) -> bool:
    sentence = sentence.strip()
    if len(sentence) > 38:
        return False
    if "、" in sentence or "；" in sentence:
        return False
    if "：" in sentence:
        sentence = sentence.rsplit("：", 1)[1].strip()
    if any(hint in sentence for hint in ("凭什么", "会怎样", "会损失什么")):
        return True
    return any(sentence.startswith(hint) for hint in QUESTION_HINTS)


def cleanup_punctuation(text: str) -> str:
    text = re.sub(r"([，；：])。", r"\1", text)
    text = text.replace("，，", "，").replace("。。", "。")
    text = text.replace("：：", "：").replace("；；", "；")
    text = text.replace("，而是因为", "，而是因为")
    text = text.replace("你，而不是找别人", "你，而不是找别人")
    text = text.replace("现在找你而不是找别人？", "现在找你，而不是找别人？")
    return text


def paragraphize(text: str) -> str:
    plain_length = len(text)
    if "：" in text:
        head, rest = text.split("：", 1)
        if 4 <= len(head) <= 65 and rest:
            return head + "：\n\n" + format_colon_rest(rest)
    units = split_sentence_units(text)
    if len(units) < 2:
        return format_single_unit(text)
    if len(units) == 2:
        return "\n\n".join(units)
    if len(units) == 3 and plain_length < 95:
        return units[0] + "\n\n" + "".join(units[1:])
    group_count = 3 if plain_length >= 95 else 2
    return "\n\n".join(group_units(units, group_count))


def format_colon_rest(rest: str) -> str:
    rest = rest.strip()
    units = split_units(rest)
    if not units:
        return rest
    if sum(unit.endswith("？") for unit in units) >= 2:
        question_lines = []
        tail = []
        in_tail = False
        for unit in units:
            if unit.endswith("？") and not in_tail:
                question_lines.append(unit)
            else:
                in_tail = True
                tail.append(unit)
        result = "\n".join(question_lines)
        if tail:
            result += "\n\n" + "".join(tail)
        return result
    if units[0].endswith("？") and len(units) > 1:
        return units[0] + "\n\n" + "".join(units[1:])
    if rest.count("；") >= 1 or rest.startswith("第一类"):
        list_lines = []
        tail = []
        for unit in units:
            if unit.endswith("；") or unit.startswith(("第一", "第二", "第三", "第四", "第五", "第六")):
                list_lines.append(unit)
            else:
                tail.append(unit)
        if list_lines:
            if len(tail) == 1 and rest.count("；") >= 1 and not rest.startswith(("第一类", "第二类", "第三类")):
                list_lines.append(tail[0])
                tail = []
            result = "\n".join(list_lines)
            if tail:
                result += "\n\n" + "".join(tail)
            return result
    sentence_units = split_sentence_units(rest)
    if len(sentence_units) > 1:
        return sentence_units[0] + "\n\n" + "".join(sentence_units[1:])
    if "，" in rest and "。" not in rest.rstrip("。！？") and should_split_colon_list(rest):
        parts = [part.strip() for part in rest.rstrip("。！？").split("，") if part.strip()]
        if 2 <= len(parts) <= 5:
            end = rest[-1] if rest[-1:] in "。！？" else ""
            lines = []
            for index, part in enumerate(parts):
                suffix = end if index == len(parts) - 1 else "；"
                lines.append(part + suffix)
            return "\n".join(lines)
    if len(rest) >= 70:
        return "\n\n".join(group_units(units, 2))
    return rest


def should_split_colon_list(rest: str) -> bool:
    signals = ("为什么", "什么", "哪里", "谁", "多长时间", "得到", "减少", "创造", "缩短", "问题", "路径", "节点")
    return sum(signal in rest for signal in signals) >= 2


def format_single_unit(text: str) -> str:
    if "；" in text and len(text) >= 32:
        parts = [part.strip() for part in text.split("；") if part.strip()]
        if 2 <= len(parts) <= 4:
            lines = []
            for index, part in enumerate(parts):
                if index < len(parts) - 1 and not part.endswith(("。", "！", "？")):
                    lines.append(part + "；")
                else:
                    lines.append(part)
            return "\n".join(lines)
    if len(text) >= 27 and "，" in text:
        midpoint = len(text) // 2
        comma_positions = [match.start() for match in re.finditer("，", text)]
        if comma_positions:
            split_at = min(comma_positions, key=lambda position: abs(position - midpoint))
            if 4 <= split_at <= len(text) - 8:
                return text[: split_at + 1] + "\n" + text[split_at + 1 :]
    return text


def split_units(text: str) -> list[str]:
    return [part for part in re.findall(r"[^。！？；：]+[。！？；：]?", text) if part]


def split_sentence_units(text: str) -> list[str]:
    return [part for part in re.findall(r"[^。！？]+[。！？]?", text) if part]


def group_units(units: list[str], group_count: int) -> list[str]:
    if group_count <= 1 or len(units) <= 1:
        return ["".join(units)]
    total = sum(len(unit) for unit in units)
    target = max(30, total // group_count)
    groups = []
    current = []
    current_len = 0
    remaining_groups = group_count
    for index, unit in enumerate(units):
        current.append(unit)
        current_len += len(unit)
        remaining_units = len(units) - index - 1
        if remaining_groups > 1 and current_len >= target and remaining_units >= remaining_groups - 1:
            groups.append("".join(current))
            current = []
            current_len = 0
            remaining_groups -= 1
    if current:
        groups.append("".join(current))
    return groups


def tidy_breaks(text: str) -> str:
    lines = [line.strip() for line in text.splitlines()]
    text = "\n".join(lines)
    text = text.replace("；\n\n每天", "。\n\n每天")
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"([。！？；])\n([^。\n])", r"\1\n\2", text)
    return text.strip()
